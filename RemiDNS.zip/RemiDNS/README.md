# RemiDNS
Android için Cloudflare WARP + AdGuard DNS (yerel VPN servisi).

## Nasıl çalışır
- **Seçili uygulamalar (Roblox, Discord vb.) açıkken:** Tam VPN (Cloudflare WARP), tünel DNS'i Cloudflare 1.1.1.1.
- **Tarayıcı, film ve diğer her yerde:** Hızlı DNS, sorgular AdGuard'a (DoH) gider + yerel reklam listesi.
- Geçişi otomatik mod yapar (Android aynı anda tek VPN'e izin verir).

Gerekenler: Ayarlar > Uygulamalar > Özel erişim > Kullanım erişimi'nden RemiDNS'e izin, pil ayarı "Kısıtlamasız", telefonda "Özel DNS" kapalı.

## APK çıkarma
1. Klasörü GitHub'a yükle (kökte `settings.gradle.kts` ve `.github` olmalı).
2. Actions > "Build APK" > Run workflow.
3. Artifacts veya Releases > latest'ten APK'yı indir.
