# RemiDNS
Android için Cloudflare WARP (tam VPN). Tünelin DNS'i tek dokunuşla **Cloudflare** ↔ **AdGuard** arasında değişir.

## Nasıl çalışır
- Seçili uygulamaların (varsayılan: hepsi) tüm trafiği Cloudflare WARP tüneline girer.
- Ana sayfadaki **Cloudflare / AdGuard** düğmesi tünelin DNS'ini anında değiştirir (bağlıyken tüneli yeni DNS ile kısa sürede yeniden kurar).
  - Cloudflare: 1.1.1.1 (reklam engelleme yok)
  - AdGuard: 94.140.14.14 (reklam + izleyici engelleme)
- Varsayılan Cloudflare; AdGuard (reklam engelleyici) yalnızca elle seçilen bir seçenektir, otomatik geçiş yoktur.

Telefonda "Özel DNS" kapalı olmalı, pil ayarı "Kısıtlamasız" önerilir.

## APK çıkarma
1. Klasörü GitHub'a yükle (kökte `settings.gradle.kts` ve `.github` olmalı).
2. Actions > "Build APK" > Run workflow.
3. Artifacts veya Releases > latest'ten APK'yı indir.
