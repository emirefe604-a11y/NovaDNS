# RemiDNS
Android için Cloudflare WARP (tam VPN). Tünelin DNS'i tek dokunuşla **Cloudflare** ↔ **AdGuard** arasında değişir.

## Nasıl çalışır
- Seçili uygulamaların (varsayılan: hepsi) tüm trafiği Cloudflare WARP tüneline girer.
- Ana sayfadaki **Cloudflare / AdGuard** düğmesi tünelin DNS'ini anında değiştirir (bağlıyken tüneli yeni DNS ile kısa sürede yeniden kurar).
  - Cloudflare: 1.1.1.1 (reklam engelleme yok)
  - AdGuard: 94.140.14.14 (reklam + izleyici engelleme)
- **Otomatik** (varsayılan): Chrome ve diğer tarayıcılar açıkken AdGuard, uygulama ve oyunlar açıkken Cloudflare. WARP hep açık kalır, yalnızca DNS değişir.
  Bunun için Ayarlar > Uygulamalar > Özel erişim > Kullanım erişimi'nden RemiDNS'e izin ver.
- Cloudflare veya AdGuard'a dokunursan otomatik kapanır, o DNS sabit kalır.

Telefonda "Özel DNS" kapalı olmalı, pil ayarı "Kısıtlamasız" önerilir.

## APK çıkarma
1. Klasörü GitHub'a yükle (kökte `settings.gradle.kts` ve `.github` olmalı).
2. Actions > "Build APK" > Run workflow.
3. Artifacts veya Releases > latest'ten APK'yı indir.
