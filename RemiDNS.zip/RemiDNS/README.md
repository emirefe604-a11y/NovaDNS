# RemiDNS
Android için DNS-over-HTTPS + reklam engelleyici + Cloudflare WARP (yerel VPN servisi).

## Modlar
- **Hızlı DNS:** Sadece DNS sorguları (DoH) yönlendirilir; resim/oyun verisi doğrudan, tam hızda gelir.
- **Tam VPN (WARP):** Seçili uygulamaların tüm trafiği WARP tünelinden geçer (otomatik sunucu seçimi, takılma/ağ değişimi izleme).

**WARP modunda reklam engelleme:** Trafik tünelden geçtiği için yerel liste çalışmaz; bunun yerine tünelin DNS'i reklam engelleyen sunucuya (Control D 76.76.2.2/76.76.10.2 (varsayılan), Mullvad Adblock 194.242.2.3, DNS4EU 86.54.11.13/86.54.11.213 veya AdGuard) yönlendirilir. Ayarlar > Reklam engelleyici bölümünden seçilir.

Uygulamalar sekmesinden hangi uygulamaların korunacağını seç. Ayarlar sekmesinden DNS sağlayıcı, reklam engelleyici ve diğer özellikler.

## APK çıkarma
1. Bu klasörü GitHub'a yükle (repo kökünde `settings.gradle.kts` ve `.github` klasörü olmalı).
2. GitHub > Actions > "Build APK" > Run workflow.
3. Bitince "Artifacts" altından veya Releases > latest'ten APK'yı indir.

## Otomatik mod
Ayarlar > Otomatik mod değiştirme: Roblox/Discord gibi seçili uygulamalar (tarayıcılar hariç) ön plandayken Tam VPN (WARP), tarayıcı ve diğer uygulamalarda Hızlı DNS çalışır. Gerekenler: Ayarlar > Uygulamalar > Özel erişim > Kullanım erişimi'nden RemiDNS'e izin ve pil ayarının "Kısıtlamasız" olması.
