package com.nova.dns

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.crypto.KeyPair
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.IOException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.net.ssl.HttpsURLConnection

/** Tam VPN modu: Cloudflare WARP (WireGuard) tüneli. Tüm trafik tünelden geçer. */
object Warp {
    @Volatile var active = false
    @Volatile var connecting = false
    @Volatile var error = ""
    @Volatile var note = ""
    @Volatile private var wantUp = false
    @Volatile private var lastEstablish = 0L
    private val lock = Any()
    private val badEps = HashMap<String, Long>()
    private var monitor: Thread? = null
    private var cm: ConnectivityManager? = null
    private var cb: ConnectivityManager.NetworkCallback? = null
    private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName() = "warp"
        override fun onStateChange(newState: Tunnel.State) { active = newState == Tunnel.State.UP }
    }

    // Cloudflare WARP uç noktaları: biri/portu engelliyse sıradakine otomatik geçer.
    private val endpoints = listOf(
        "162.159.192.1:2408", "162.159.192.1:500", "162.159.192.1:4500", "162.159.193.1:2408",
        "188.114.97.1:2408", "188.114.99.1:2408", "162.159.195.1:2408"
    )

    fun connect(ctx: Context) {
        val app = ctx.applicationContext
        wantUp = true
        note = ""
        Thread {
            synchronized(lock) { establish(app) }
            if (active && wantUp) { startWatch(app); watchNetwork(app) }
        }.start()
    }

    /** Bağlantıyı kurar: en iyi (son çalışan) uç noktayı önce dener, çalışmayanları atlar. */
    private fun establish(app: Context) {
        connecting = true
        error = ""
        try {
            val prefs = Prefs(app)
            val custom = prefs.wgCustom.trim().isNotEmpty()
            var cfg = prefs.wgCustom.trim()
            if (cfg.isEmpty()) {
                cfg = prefs.warpCfg
                if (cfg.isEmpty()) { cfg = register(); prefs.warpCfg = cfg }
            }
            val apps = Targets.vpnApps(app)
            val dns = if (prefs.adblock && prefs.blockAds) "94.140.14.14, 94.140.15.15" else "1.1.1.1, 1.0.0.1"
            val b = backend ?: GoBackend(app).also { backend = it }
            if (active) { try { b.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {} }
            val now = System.currentTimeMillis()
            val all = (listOf(prefs.warpEp).filter { it.isNotEmpty() } + endpoints).distinct()
            val parts = all.partition { (badEps[it] ?: 0L) < now - 120_000 }
            val order: List<String?> = if (custom) listOf<String?>(null) else parts.first + parts.second
            var ok = false
            var lastErr = ""
            for (ep in order) {
                try {
                    val c0 = if (ep != null) cfg.replace(Regex("""(?m)^Endpoint\s*=.*$"""), "Endpoint = $ep") else cfg
                    b.setState(tunnel, Tunnel.State.UP, Config.parse(ByteArrayInputStream(tune(c0, apps, !custom, dns).toByteArray())))
                    if (ep == null) { ok = true; break }
                    var n = 0
                    while (n < 10 && !ok) {
                        Thread.sleep(300)
                        n++
                        ok = try { b.getStatistics(tunnel).totalRx() > 0 } catch (e: Exception) { false }
                    }
                    if (ok) { prefs.warpEp = ep; badEps.remove(ep); break }
                    badEps[ep] = System.currentTimeMillis()
                } catch (e: Exception) {
                    lastErr = e.message ?: e.javaClass.simpleName
                }
                try { b.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
            }
            if (!ok) error = if (lastErr.isNotEmpty()) "Hata: $lastErr" else "Sunucuya ulaşılamadı. Başka bir ağ (Wi-Fi / mobil veri) dene."
        } catch (e: Exception) {
            error = "Hata: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            lastEstablish = System.currentTimeMillis()
            connecting = false
        }
    }

    /** Sürekli izleme: veri gidiyor ama hiçbir şey gelmiyorsa (takılma) sunucuyu değiştirip yeniden bağlanır. */
    private fun startWatch(app: Context) {
        stopWatch()
        val t = Thread {
            var lastRx = -1L
            var lastTx = 0L
            var stall = 0
            while (wantUp) {
                try { Thread.sleep(8000) } catch (_: InterruptedException) { return@Thread }
                if (!wantUp) return@Thread
                if (connecting) { lastRx = -1L; continue }
                val st = try { backend?.getStatistics(tunnel) } catch (_: Exception) { null } ?: continue
                val rx = st.totalRx()
                val tx = st.totalTx()
                // Keepalive ~32 bayt; 2 KB'den fazla giden veri = gerçek trafik.
                if (lastRx >= 0 && tx - lastTx > 2000 && rx - lastRx <= 0) stall++ else stall = 0
                lastRx = rx
                lastTx = tx
                if (stall >= 2) {
                    stall = 0
                    lastRx = -1L
                    val prefs = Prefs(app)
                    if (prefs.warpEp.isNotEmpty()) { badEps[prefs.warpEp] = System.currentTimeMillis(); prefs.warpEp = "" }
                    synchronized(lock) { if (wantUp) establish(app) }
                    note = if (active) "Otomatik optimize edildi" else ""
                }
            }
        }
        t.isDaemon = true
        monitor = t
        t.start()
    }

    private fun stopWatch() { monitor?.interrupt(); monitor = null }

    /** Wi-Fi <-> mobil veri geçişinde otomatik yeniden bağlanır. */
    private fun watchNetwork(app: Context) {
        unwatchNetwork()
        try {
            val m = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val c = object : ConnectivityManager.NetworkCallback() {
                private var first = true
                override fun onAvailable(network: Network) {
                    if (first) { first = false; return }
                    if (!wantUp || connecting || System.currentTimeMillis() - lastEstablish < 5000) return
                    Thread {
                        synchronized(lock) { if (wantUp) establish(app) }
                        note = if (active) "Ağ değişti, otomatik yenilendi" else ""
                    }.start()
                }
            }
            m.registerDefaultNetworkCallback(c)
            cm = m
            cb = c
        } catch (_: Exception) {}
    }

    private fun unwatchNetwork() {
        try { cb?.let { cm?.unregisterNetworkCallback(it) } } catch (_: Exception) {}
        cb = null
    }

    fun disconnect() {
        wantUp = false
        stopWatch()
        unwatchNetwork()
        Thread {
            synchronized(lock) {
                try { backend?.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
            }
            active = false
            note = ""
        }.start()
    }

    private fun tune(cfg0: String, apps: List<String>, auto: Boolean, dns: String): String {
        var cfg = cfg0.trimEnd() + "\n"
        if (auto) {
            // Kararlılık: 1280 MTU parçalanmayı (fragmentation) önler, mobil ağlarda en tutarlı hızı verir.
            cfg = cfg.replace(Regex("""(?m)^MTU\s*=.*$"""), "MTU = 1280")
            cfg = cfg.replace(Regex("""(?m)^DNS\s*=.*$"""), "DNS = $dns")
        }
        if (!cfg.contains("PersistentKeepalive")) cfg += "PersistentKeepalive = 25\n"
        if (apps.isEmpty() || cfg.contains("IncludedApplications") || cfg.contains("ExcludedApplications")) return cfg
        return cfg.replaceFirst("[Interface]", "[Interface]\nIncludedApplications = " + apps.joinToString(", "))
    }

    /** Cloudflare WARP için ücretsiz hesap kaydı (wgcf ile aynı yöntem). */
    private fun register(): String {
        val kp = KeyPair()
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val body = JSONObject()
            .put("key", kp.publicKey.toBase64())
            .put("install_id", "")
            .put("fcm_token", "")
            .put("tos", fmt.format(Date()))
            .put("type", "Android")
            .put("model", "PC")
            .put("locale", "en_US")
        val c = URL("https://api.cloudflareclient.com/v0a1922/reg").openConnection() as HttpsURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 10000
        c.readTimeout = 10000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("User-Agent", "okhttp/3.12.1")
        c.setRequestProperty("CF-Client-Version", "a-6.3-2596")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) throw IOException("WARP kaydı başarısız (${c.responseCode})")
        val resp = JSONObject(c.inputStream.use { String(it.readBytes()) })
        val cfg = resp.getJSONObject("config")
        val peer = cfg.getJSONArray("peers").getJSONObject(0)
        val pub = peer.getString("public_key")
        val addrs = cfg.getJSONObject("interface").getJSONObject("addresses")
        val v6 = addrs.optString("v6", "")
        val addr = addrs.getString("v4") + "/32" + (if (v6.isNotEmpty()) ", $v6/128" else "")
        val allowed = if (v6.isNotEmpty()) "0.0.0.0/0, ::/0" else "0.0.0.0/0"
        return "[Interface]\n" +
            "PrivateKey = ${kp.privateKey.toBase64()}\n" +
            "Address = $addr\n" +
            "DNS = 1.1.1.1, 1.0.0.1\n" +
            "MTU = 1280\n\n" +
            "[Peer]\n" +
            "PublicKey = $pub\n" +
            "AllowedIPs = $allowed\n" +
            "Endpoint = 162.159.192.1:2408\n"
    }
}
