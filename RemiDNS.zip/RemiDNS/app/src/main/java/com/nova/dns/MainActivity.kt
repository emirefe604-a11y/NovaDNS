package com.nova.dns

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.widget.ScrollView
import android.widget.TextView

object C {
    val BG = 0xFF0B1020.toInt()        // logo zemini
    val BG2 = 0xFF2B0C16.toInt()       // koyu kırmızımsı ton
    val CARD = 0xFF161524.toInt()
    val FIELD = 0xFF0F1124.toInt()
    val STROKE = 0xFF3A2A3C.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val MUTED = 0xFF9A9DB5.toInt()
    val ACCENT = 0xFFFF2D3D.toInt()    // logo kırmızısı
    val ACCENT2 = 0xFFFF6B78.toInt()
    val GREEN = 0xFF2ED573.toInt()
    val GREEN2 = 0xFF00D2D3.toInt()
    val TEAL = 0xFFFF8A94.toInt()      // açık mercan (vurgu)
    val SEL = 0x33FF2D3D
}

class PowerButton(c: Context) : View(c) {
    private var on = false
    private var busy = false
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    fun setState(active: Boolean, connecting: Boolean) {
        if (active != on || connecting != busy) { on = active; busy = connecting; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val breathe = 1f + 0.03f * sin(t * 2f * PI.toFloat())
        val r = minOf(width, height) / 2f * 0.58f * breathe
        p.shader = null
        p.style = Paint.Style.FILL
        if (on) {
            for (k in 0..1) {
                val ph = (t + k * 0.5f) % 1f
                p.color = Color.argb((80 * (1 - ph)).toInt(), 46, 213, 115)
                c.drawCircle(cx, cy, r * (1f + 0.65f * ph), p)
            }
        }
        p.color = if (on) 0x222ED573 else 0x22FF2D3D
        c.drawCircle(cx, cy, r * 1.22f, p)
        p.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            if (on) C.GREEN else C.ACCENT, if (on) C.GREEN2 else C.ACCENT2, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        if (busy) {
            p.strokeWidth = r * 0.09f
            p.color = C.TEAL
            val ring = r * 1.3f
            c.drawArc(RectF(cx - ring, cy - ring, cx + ring, cy + ring), t * 360f, 110f, false, p)
            p.color = C.ACCENT2
            c.drawArc(RectF(cx - ring, cy - ring, cx + ring, cy + ring), t * 360f + 180f, 60f, false, p)
        }
        p.strokeWidth = r * 0.13f
        p.color = Color.WHITE
        val ir = r * 0.42f
        c.drawArc(RectF(cx - ir, cy - ir, cx + ir, cy + ir), -60f, 300f, false, p)
        c.drawLine(cx, cy - ir * 1.2f, cx, cy - ir * 0.05f, p)
    }
}

data class AppItem(val pkg: String, val label: String, val icon: Drawable?)

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var prefs: Prefs

    // Ana sayfa
    private lateinit var power: PowerButton
    private lateinit var titleTv: TextView
    private lateinit var sub: TextView
    private lateinit var timeNum: TextView
    private lateinit var appsNum: TextView
    private lateinit var segDns: TextView
    private lateinit var segWarp: TextView
    private lateinit var modeDesc: TextView
    private lateinit var modeChip: TextView

    // Sekmeler
    private lateinit var pages: List<View>
    private lateinit var tabs: List<TextView>

    // Uygulamalar
    private lateinit var appsBox: LinearLayout
    private lateinit var countTv: TextView
    private var allApps: List<AppItem> = emptyList()
    private var filter = ""
    private val selected = HashSet<String>()

    private var selCount = 0
    private var connectedAt = 0L
    private var lastTitle = ""

    // Destek ekranı (açılışta ve VPN başlatılırken kısa süre görünür, sonra kapanır)
    private lateinit var overlay: FrameLayout
    private val hideRunnable = Runnable { hideSupport() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int = 0, strokeColor: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke > 0) setStroke(dp(stroke), strokeColor)
        }

    private fun tv(t: String, size: Float, color: Int = C.TEXT, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun lp(top: Int = 0, bottom: Int = 0, w: Int = -1, h: Int = -2, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(C.CARD, 18, 1, C.STROKE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun page(): Pair<ScrollView, LinearLayout> {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(16))
        }
        return Pair(ScrollView(this).apply { addView(col) }, col)
    }

    private fun switchRow(title: String, desc: String, init: Boolean, onChange: (Boolean) -> Unit): Pair<LinearLayout, Switch> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(title, 15f, bold = true))
        col.addView(tv(desc, 12f, C.MUTED))
        val sw = Switch(this).apply {
            tintAccent(this)
            isChecked = init
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(sw)
        return Pair(row, sw)
    }

    private fun states() = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())

    private fun tintAccent(sw: Switch) {
        sw.thumbTintList = ColorStateList(states(), intArrayOf(C.ACCENT, 0xFF9A9DB5.toInt()))
        sw.trackTintList = ColorStateList(states(), intArrayOf(0x66FF2D3D, 0xFF2A2B3F.toInt()))
    }

    private fun field(ph: String, init: String, lines: Int, onChange: (String) -> Unit): EditText =
        EditText(this).apply {
            setText(init)
            hint = ph
            setTextColor(C.TEXT)
            setHintTextColor(C.MUTED)
            textSize = 14f
            background = shape(C.FIELD, 12, 1, C.STROKE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            if (lines > 1) {
                minLines = lines
                gravity = Gravity.TOP
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            } else {
                setSingleLine(true)
            }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { onChange(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }

    private fun button(t: String, onClick: () -> Unit) = tv(t, 14f, C.TEXT, true).apply {
        gravity = Gravity.CENTER
        background = shape(C.ACCENT, 12)
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setOnClickListener { onClick() }
    }

    private fun section(t: String) = tv(t, 13f, C.ACCENT2, true).apply { setPadding(dp(4), dp(16), 0, dp(6)) }

    private fun isActive() = Warp.active

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        prefs.selectedRaw?.let { selected.addAll(it) }
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.BG, C.BG2)))
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG2

        val (homePage, home) = page()
        val (appsPage, appsCol) = page()
        val (setPage, setCol) = page()
        buildHome(home)
        buildApps(appsCol)
        buildSettings(setCol)

        val frame = FrameLayout(this)
        pages = listOf(homePage, appsPage, setPage)
        for (p in pages) frame.addView(p, FrameLayout.LayoutParams(-1, -1))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(C.CARD)
        }
        val names = listOf("Ana sayfa", "Uygulamalar", "Ayarlar")
        tabs = names.mapIndexed { i, n ->
            tv(n, 13f, C.MUTED, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, dp(14))
                setOnClickListener { selectTab(i) }
            }
        }
        for (t in tabs) bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        overlay = buildSupportOverlay()
        val outer = FrameLayout(this)
        outer.addView(root, FrameLayout.LayoutParams(-1, -1))
        outer.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(outer)
        selectTab(0)
        updateMode()
        loadApps()
        if (b == null) { showSupport(); if (!isActive()) toggle() } // açılışta otomatik bağlan
    }

    private fun buildSupportOverlay(): FrameLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        col.addView(tv("😘", 72f).apply { gravity = Gravity.CENTER })
        col.addView(tv("Destek için Efe Bey'e\nöpücük atabilirsiniz", 24f, C.TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(10))
        })
        col.addView(tv("Kapatmak için dokun", 12f, C.MUTED).apply { gravity = Gravity.CENTER })
        return FrameLayout(this).apply {
            setBackgroundColor(0xF20B1020.toInt())
            visibility = View.GONE
            isClickable = true
            setOnClickListener { hideSupport() }
            addView(col, FrameLayout.LayoutParams(-1, -1))
        }
    }

    private fun showSupport() {
        h.removeCallbacks(hideRunnable)
        overlay.animate().cancel()
        overlay.visibility = View.VISIBLE
        overlay.alpha = 0f
        overlay.animate().alpha(1f).setDuration(250).start()
        h.postDelayed(hideRunnable, 2800)
    }

    private fun hideSupport() {
        h.removeCallbacks(hideRunnable)
        if (overlay.visibility != View.VISIBLE) return
        overlay.animate().cancel()
        overlay.animate().alpha(0f).setDuration(300).withEndAction { overlay.visibility = View.GONE }.start()
    }

    private fun pkgInstalled(pkg: String) = try { packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }

    private fun selectTab(i: Int) {
        for (k in pages.indices) {
            pages[k].visibility = if (k == i) View.VISIBLE else View.GONE
            tabs[k].setTextColor(if (k == i) C.ACCENT2 else C.MUTED)
        }
    }

    // ---------------------------------------------------------------- Ana sayfa
    private fun buildHome(root: LinearLayout) {
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        head.addView(tv("RemiDNS", 28f, bold = true).apply { setPadding(dp(10), 0, 0, 0) })
        root.addView(head)
        root.addView(tv("Cloudflare WARP  •  Tam VPN", 13f, C.MUTED))

        power = PowerButton(this).apply { setOnClickListener { toggle() } }
        root.addView(power, lp(top = 12, h = dp(250)))

        titleTv = tv("", 26f, bold = true).apply { gravity = Gravity.CENTER }
        sub = tv("", 13f, C.MUTED).apply { gravity = Gravity.CENTER }
        root.addView(titleTv)
        root.addView(sub, lp(top = 2, bottom = 10))
        modeChip = tv("", 12f, C.TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = shape(C.SEL, 20, 1, C.ACCENT)
        }
        root.addView(modeChip, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(18)
        })

        // DNS seçimi: tünel içinde Cloudflare <-> AdGuard hızlı geçiş
        val modeCard = card()
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = shape(C.FIELD, 12, 1, C.STROKE)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        segWarp = tv("Cloudflare", 14f, bold = true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)); setOnClickListener { setDns(DnsChoice.CLOUDFLARE) }
        }
        segDns = tv("AdGuard", 14f, bold = true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)); setOnClickListener { setDns(DnsChoice.ADGUARD) }
        }
        seg.addView(segWarp, lp(w = 0, weight = 1f))
        seg.addView(segDns, lp(w = 0, weight = 1f))
        modeDesc = tv("", 12f, C.MUTED).apply { setPadding(0, dp(8), 0, 0) }
        modeCard.addView(tv("DNS (varsayılan Cloudflare, AdGuard = reklam engelleyici)", 12f, C.MUTED).apply { setPadding(0, 0, 0, dp(6)) })
        modeCard.addView(seg)
        modeCard.addView(modeDesc)
        root.addView(modeCard, lp(bottom = 14))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timeNum = tv("--:--", 24f, bold = true)
        appsNum = tv("0", 24f, C.GREEN, true)
        row1.addView(card().apply { addView(tv("Bağlantı süresi", 12f, C.MUTED)); addView(timeNum) }, lp(w = 0, weight = 1f).apply { rightMargin = dp(6) })
        row1.addView(card().apply { addView(tv("Korunan uygulama", 12f, C.MUTED)); addView(appsNum) }, lp(w = 0, weight = 1f).apply { leftMargin = dp(6) })
        root.addView(row1, lp(bottom = 12))

        for (i in 0 until root.childCount) {
            val v = root.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(28).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 60L).setDuration(480)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun styleSeg(t: TextView, on: Boolean) {
        t.setTextColor(if (on) C.TEXT else C.MUTED)
        t.background = if (on) shape(C.ACCENT, 10) else null
    }

    private fun updateMode() {
        val d = prefs.dns
        styleSeg(segWarp, d == DnsChoice.CLOUDFLARE)
        styleSeg(segDns, d == DnsChoice.ADGUARD)
        modeDesc.text = d.desc
    }

    /** Anında geçiş: seçimi kaydeder, bağlıysa tüneli yeni DNS ile yeniden kurar. */
    private fun setDns(d: DnsChoice) {
        if (prefs.dns == d) return
        if (isActive()) Warp.applyDns(this, d) else prefs.dns = d
        updateMode()
    }

    private fun toggle() {
        if (isActive() || Warp.connecting) { if (isActive()) stopAll(); return }
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, 2) else startWarp()
    }

    private fun startWarp() {
        Warp.connect(this)
    }

    private fun stopAll() {
        if (Warp.active || Warp.connecting) Warp.disconnect()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 2 && res == RESULT_OK) startWarp()
    }

    // ---------------------------------------------------------------- Uygulamalar
    private fun buildApps(root: LinearLayout) {
        root.addView(tv("Uygulamalar", 28f, bold = true))
        root.addView(tv("Seçili uygulamalar koruma üzerinden internete çıkar. Diğerleri normal çalışır.", 13f, C.MUTED), lp(bottom = 12))
        root.addView(field("Uygulama ara...", "", 1) { filter = it; renderApps() }, lp(bottom = 8))
        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnRow.addView(button("Hepsini seç") { setAll(true) }, lp(w = 0, weight = 1f).apply { rightMargin = dp(6) })
        btnRow.addView(button("Hepsini kaldır") { setAll(false) }.apply { background = shape(0, 12, 1, C.ACCENT) }, lp(w = 0, weight = 1f).apply { leftMargin = dp(6) })
        root.addView(btnRow, lp(bottom = 8))
        countTv = tv("", 12f, C.TEAL, true)
        root.addView(countTv, lp(bottom = 6))
        appsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(appsBox)
        appsBox.addView(tv("Uygulamalar yükleniyor...", 13f, C.MUTED))
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(intent, 0)
                .map { it.activityInfo.packageName }
                .distinct()
                .filter { it != packageName }
                .map { pkg ->
                    val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
                    val icon = try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null }
                    AppItem(pkg, label, icon)
                }
                .sortedWith(compareByDescending<AppItem> { it.pkg in Targets.banned }.thenBy { it.label.lowercase() })
            runOnUiThread {
                allApps = list
                if (prefs.selectedRaw == null) selected.addAll(list.map { it.pkg })
                renderApps()
            }
        }.start()
    }

    private fun shownApps(): List<AppItem> {
        val q = filter.trim().lowercase()
        return allApps.filter { q.isEmpty() || it.label.lowercase().contains(q) || it.pkg.contains(q) }
    }

    /** Arama yapılıyorsa görünenleri, yoksa tüm uygulamaları seç / kaldır. */
    private fun setAll(on: Boolean) {
        val pkgs = shownApps().map { it.pkg }
        if (on) selected.addAll(pkgs) else selected.removeAll(pkgs.toSet())
        prefs.selectedRaw = HashSet(selected)
        renderApps()
        refreshApps()
        if (isActive()) Toast.makeText(this, "Değişiklik, VPN'i yeniden bağlayınca geçerli olur.", Toast.LENGTH_SHORT).show()
    }

    private fun renderApps() {
        appsBox.removeAllViews()
        for (a in shownApps()) appsBox.addView(appRow(a))
        countTv.text = "${selected.size} uygulama seçili"
    }

    private fun appRow(a: AppItem): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        row.addView(ImageView(this).apply { setImageDrawable(a.icon) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
        col.addView(tv(a.label, 15f, bold = true))
        if (a.pkg in Targets.banned) col.addView(tv("Önerilen · Türkiye'de erişim kısıtlı", 11f, C.TEAL))
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        val cb = CheckBox(this).apply {
            buttonTintList = ColorStateList(states(), intArrayOf(C.ACCENT, 0xFF9A9DB5.toInt()))
            isChecked = a.pkg in selected
            setOnCheckedChangeListener { _, v ->
                if (v) selected.add(a.pkg) else selected.remove(a.pkg)
                prefs.selectedRaw = HashSet(selected)
                countTv.text = "${selected.size} uygulama seçili"
                refreshApps()
                if (isActive()) Toast.makeText(this@MainActivity, "Değişiklik, VPN'i yeniden bağlayınca geçerli olur.", Toast.LENGTH_SHORT).show()
            }
        }
        row.addView(cb)
        row.setOnClickListener { cb.toggle() }
        return row
    }

    // ---------------------------------------------------------------- Ayarlar
    private fun buildSettings(root: LinearLayout) {
        root.addView(tv("Ayarlar", 28f, bold = true))
        root.addView(section("GENEL"))
        val prCard = card()
        prCard.addView(switchRow("Açılışta otomatik başlat", "Telefon açılınca WARP kendiliğinden bağlanır", prefs.autostart) { prefs.autostart = it }.first)
        prCard.addView(tv("Telefonda \"Özel DNS\" kapalı olmalı. Pil ayarı: Uygulamalar > RemiDNS > Pil > \"Kısıtlamasız\".", 11f, C.MUTED).apply { setPadding(0, dp(8), 0, 0) })
        root.addView(prCard)
    }

    // ---------------------------------------------------------------- Durum
    private fun refreshApps() {
        selCount = Targets.vpnApps(this).filter { it != packageName }.size.let { if (Targets.vpnApps(this).isEmpty()) -1 else it }
    }

    private fun setTitle2(t: String, color: Int) {
        if (t == lastTitle) return
        val first = lastTitle.isEmpty()
        lastTitle = t
        if (first) { titleTv.text = t; titleTv.setTextColor(color); return }
        titleTv.animate().setStartDelay(0).alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(120).withEndAction {
            titleTv.text = t
            titleTv.setTextColor(color)
            titleTv.animate().setStartDelay(0).alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).start()
        }.start()
    }

    private val tick = object : Runnable {
        override fun run() {
            val a = isActive()
            val busy = Warp.connecting
            updateMode()
            val d = prefs.dns
            modeChip.text = "🛡  Tam VPN · WARP  ·  ${d.label}"
            modeChip.setTextColor(if (a) C.GREEN else C.ACCENT2)
            modeChip.background = shape(if (a) 0x222ED573 else C.SEL, 20, 1, if (a) C.GREEN else C.ACCENT)
            power.setState(a, busy)
            appsNum.text = if (selCount < 0) "Tümü" else selCount.toString()
            if (busy) setTitle2("Bağlanıyor...", C.TEXT)
            else setTitle2(if (a) "Bağlandı" else "Bağlı değil", if (a) C.GREEN else C.TEXT)
            sub.text = when {
                busy -> "En hızlı sunucu seçiliyor..."
                a -> "Cloudflare WARP ile korunuyorsun\n" + (if (Warp.note.isNotEmpty()) Warp.note else "Otomatik optimizasyon açık")
                Warp.error.isNotEmpty() -> Warp.error
                else -> "Bağlanmak için düğmeye dokun"
            }
            if (a) {
                if (connectedAt == 0L) connectedAt = System.currentTimeMillis()
                val sec = (System.currentTimeMillis() - connectedAt) / 1000
                timeNum.text = if (sec >= 3600) String.format("%d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
                else String.format("%02d:%02d", sec / 60, sec % 60)
            } else {
                connectedAt = 0L
                timeNum.text = "--:--"
            }
            h.postDelayed(this, 1000)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshApps()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
        h.removeCallbacks(hideRunnable)
        overlay.animate().cancel()
        overlay.visibility = View.GONE
    }
}
