package com.nova.dns

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = Prefs(c)
        if (!prefs.autostart || VpnService.prepare(c) != null) return
        if (prefs.mode == 1) Warp.connect(c) else c.startService(Intent(c, DnsVpnService::class.java))
        if (prefs.autoSwitch && AutoSwitch.hasAccess(c)) AutoSwitch.start(c, prefs.mode)
    }
}
