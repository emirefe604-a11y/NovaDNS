package com.nova.dns

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process

/**
 * Otomatik DNS: WARP tam VPN hep açık kalır, yalnızca tünelin DNS'i değişir.
 * - Tarayıcı (Chrome vb., reklam girilen yerler) ön plandayken -> AdGuard
 * - Uygulama ve oyunlar ön plandayken -> Cloudflare
 * Ön plandaki uygulamayı görmek için "Kullanım erişimi" izni gerekir.
 */
object AutoDns {
    @Volatile private var running = false
    private var thread: Thread? = null

    val browsers = setOf(
        "com.android.chrome", "org.mozilla.firefox", "com.sec.android.app.sbrowser", "com.microsoft.emmx",
        "com.opera.browser", "com.opera.mini.native", "com.brave.browser", "com.duckduckgo.mobile.android",
        "com.vivaldi.browser", "com.google.android.googlequicksearchbox", "com.kiwibrowser.browser",
        "com.UCMobile.intl", "mark.via.gp"
    )

    fun hasAccess(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        else
            @Suppress("DEPRECATION") ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) { false }

    private fun homePackages(ctx: Context): Set<String> {
        val s = HashSet<String>()
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            ctx.packageManager.queryIntentActivities(i, 0).forEach { s.add(it.activityInfo.packageName) }
        } catch (_: Exception) {}
        s.add("com.android.systemui")
        return s
    }

    private fun foreground(ctx: Context, last: String?): String? = try {
        val um = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = um.queryEvents(now - 15_000, now)
        val e = UsageEvents.Event()
        var pkg = last
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) pkg = e.packageName
        }
        pkg
    } catch (_: Exception) { last }

    /** Otomatik mod açıksa ve izin varsa izlemeyi başlatır (tekrar çağrılabilir). */
    fun start(ctx: Context) {
        val app = ctx.applicationContext
        if (running || !Prefs(app).dnsAuto || !hasAccess(app)) return
        running = true
        val t = Thread {
            var lastPkg: String? = null
            var pending: DnsChoice? = null
            var pendingN = 0
            var lastSwitch = 0L
            val home = homePackages(app)
            while (running) {
                try { Thread.sleep(1000) } catch (_: InterruptedException) { return@Thread }
                if (!running) return@Thread
                val p = Prefs(app)
                if (!p.dnsAuto || !Warp.active) { pending = null; continue }
                lastPkg = foreground(app, lastPkg)
                val pkg = lastPkg ?: continue
                if (pkg == app.packageName || pkg in home) { pending = null; continue } // nötr: mevcut DNS kalır
                val want = if (pkg in browsers) DnsChoice.ADGUARD else DnsChoice.CLOUDFLARE
                if (want == p.dns) { pending = null; continue }
                if (want == pending) pendingN++ else { pending = want; pendingN = 1 }
                if (pendingN < 2 || System.currentTimeMillis() - lastSwitch < 4000) continue
                if (Warp.applyDns(app, want)) { lastSwitch = System.currentTimeMillis(); pending = null }
            }
        }
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
    }
}
