package com.nova.dns

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process

/**
 * Otomatik mod: ön plandaki uygulamaya göre Tam VPN (WARP) ile Hızlı DNS arasında geçiş yapar.
 * - Yasaklı / seçili uygulama (Roblox, Discord vb.) açıkken -> Tam VPN (WARP)
 * - Tarayıcı ve diğer her şey (film, Google...) -> Hızlı DNS (geniş reklam listesi + tam hız)
 * Android aynı anda tek VPN'e izin verdiği için biri kapatılıp diğeri açılır.
 * Ön plandaki uygulamayı görmek için "Kullanım erişimi" izni gerekir.
 */
object AutoSwitch {
    @Volatile var running = false
    /** 0 = Hızlı DNS, 1 = Tam VPN (WARP). Ekranda gösterilen mod. */
    @Volatile var current = 1
    @Volatile var note = ""
    private var thread: Thread? = null
    @Volatile private var switching = false

    // Tarayıcılar WARP tetiklemez; film/Google gezintisi Hızlı DNS'te kalır.
    private val browsers = setOf(
        "com.android.chrome", "org.mozilla.firefox", "com.sec.android.app.sbrowser", "com.microsoft.emmx",
        "com.opera.browser", "com.brave.browser", "com.duckduckgo.mobile.android", "com.vivaldi.browser"
    )

    fun hasAccess(ctx: Context): Boolean {
        return try {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29)
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            else
                @Suppress("DEPRECATION") ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) { false }
    }

    /** WARP'ı tetikleyen uygulamalar: seçili uygulamalar (tarayıcılar hariç); seçim yoksa Roblox + Discord. */
    private fun triggers(p: Prefs): Set<String> = ((p.selectedRaw ?: Targets.banned.toSet()) - browsers)

    private fun homePackages(ctx: Context): Set<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val s = HashSet<String>()
        try { ctx.packageManager.queryIntentActivities(i, 0).forEach { s.add(it.activityInfo.packageName) } } catch (_: Exception) {}
        s.add("com.android.systemui")
        return s
    }

    private fun foreground(ctx: Context, last: String?): String? {
        return try {
            val um = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val ev = um.queryEvents(now - 15_000, now)
            val e = UsageEvents.Event()
            var pkg = last
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) pkg = e.packageName
            }
            pkg
        } catch (_: Exception) { last }
    }

    fun start(ctx: Context, initial: Int) {
        val app = ctx.applicationContext
        if (running) return
        running = true
        current = initial
        note = ""
        val t = Thread {
            val started = System.currentTimeMillis()
            var lastPkg: String? = null
            var pending = -1
            var pendingN = 0
            var lastSwitch = 0L
            val home = homePackages(app)
            while (running) {
                try { Thread.sleep(1500) } catch (_: InterruptedException) { return@Thread }
                if (!running) return@Thread
                val anyUp = Warp.active || Warp.connecting || DnsVpnService.active
                if (!switching && !anyUp && System.currentTimeMillis() - started > 10_000) { running = false; return@Thread }
                if (switching) continue
                val p = Prefs(app)
                lastPkg = foreground(app, lastPkg)
                val pkg = lastPkg ?: continue
                if (pkg == app.packageName || pkg in home) { pending = -1; continue } // nötr: mevcut modu koru
                val want = if (pkg in triggers(p)) 1 else 0
                if (want == current) { pending = -1; continue }
                if (want == pending) pendingN++ else { pending = want; pendingN = 1 }
                if (pendingN < 2 || System.currentTimeMillis() - lastSwitch < 6000) continue
                pending = -1
                lastSwitch = System.currentTimeMillis()
                switchTo(app, want)
            }
        }
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
        note = ""
    }

    private fun waitUntil(max: Long, cond: () -> Boolean) {
        val end = System.currentTimeMillis() + max
        while (System.currentTimeMillis() < end && !cond()) {
            try { Thread.sleep(150) } catch (_: InterruptedException) { return }
        }
    }

    private fun switchTo(app: Context, want: Int) {
        switching = true
        try {
            if (want == 1) {
                if (DnsVpnService.active) {
                    app.startService(Intent(app, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
                    waitUntil(3000) { !DnsVpnService.active }
                }
                Warp.connect(app)
            } else {
                if (Warp.active || Warp.connecting) {
                    Warp.disconnect()
                    waitUntil(5000) { !Warp.active && !Warp.connecting }
                }
                app.startService(Intent(app, DnsVpnService::class.java))
            }
            current = want
            note = if (want == 1) "Otomatik: Tam VPN (WARP)" else "Otomatik: Hızlı DNS"
        } catch (e: Exception) {
            // Arka planda servis başlatma kısıtlanmış olabilir (pil tasarrufu). Pil ayarını "Kısıtlamasız" yap.
            note = "Mod değişemedi: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            switching = false
        }
    }
}
