package com.nova.dns

import android.content.Context
import android.content.Intent
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.URL
import javax.net.ssl.HttpsURLConnection

data class Provider(val name: String, val desc: String, val ip: String, val doh: String?)

object Providers {
    /** Gezinirken (Hızlı DNS): AdGuard reklam engelleyici DNS. Reklam engeli kapalıysa Cloudflare. */
    val adguard = Provider("AdGuard", "94.140.14.14", "94.140.14.14", "https://94.140.14.14/dns-query")
    val cloudflare = Provider("Cloudflare", "1.1.1.1", "1.1.1.1", "https://1.1.1.1/dns-query")
}

/** WARP (tam VPN) tüneli içinde DNS her zaman Cloudflare'dir. */
object WarpDns {
    const val PLAIN = "1.1.1.1, 1.0.0.1"
    @Suppress("UNUSED_PARAMETER") fun servers(p: Prefs): String = PLAIN
}

class Prefs(c: Context) {
    private val p = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    /** Ön plandaki uygulamaya göre Tam VPN (WARP) <-> Hızlı DNS otomatik geçiş. */
    var autoSwitch: Boolean
        get() = p.getBoolean("autoSwitch", true)
        set(v) = p.edit().putBoolean("autoSwitch", v).apply()
    var doh: Boolean
        get() = p.getBoolean("doh", true)
        set(v) = p.edit().putBoolean("doh", v).apply()
    var adblock: Boolean
        get() = p.getBoolean("adblock", true)
        set(v) = p.edit().putBoolean("adblock", v).apply()
    var autostart: Boolean
        get() = p.getBoolean("autostart", false)
        set(v) = p.edit().putBoolean("autostart", v).apply()
    var customBlockedRaw: String
        get() = p.getString("customBlocked", "") ?: ""
        set(v) = p.edit().putString("customBlocked", v).apply()

    var excluded: Set<String>
        get() = p.getStringSet("excluded", emptySet()) ?: emptySet()
        set(v) = p.edit().putStringSet("excluded", HashSet(v)).apply()

    var fullVpn: Boolean
        get() = p.getBoolean("fullVpn", true)
        set(v) = p.edit().putBoolean("fullVpn", v).apply()
    var wgCustom: String
        get() = p.getString("wgCustom", "") ?: ""
        set(v) = p.edit().putString("wgCustom", v).apply()
    var warpCfg: String
        get() = p.getString("warpCfg", "") ?: ""
        set(v) = p.edit().putString("warpCfg", v).apply()

    var warpEp: String
        get() = p.getString("warpEp", "") ?: ""
        set(v) = p.edit().putString("warpEp", v).apply()

    /** 0 = Hızlı DNS (sadece DNS yönlendirilir), 1 = Tam VPN (WARP). */
    var mode: Int
        get() = p.getInt("mode", 1)
        set(v) = p.edit().putInt("mode", v).apply()
    var blockAds: Boolean
        get() = p.getBoolean("blockAds", true)
        set(v) = p.edit().putBoolean("blockAds", v).apply()
    var blockTrackers: Boolean
        get() = p.getBoolean("blockTrackers", true)
        set(v) = p.edit().putBoolean("blockTrackers", v).apply()
    /** Kullanıcının seçtiği uygulamalar. null = henüz seçilmedi (varsayılan: Roblox + Discord). */
    var selectedRaw: Set<String>?
        get() = p.getStringSet("selected", null)
        set(v) = p.edit().putStringSet("selected", if (v == null) null else HashSet(v)).apply()

    /** Reklam engelleyici, Hızlı DNS modunda tüm uygulamalar için çalışsın. */
    var adAll: Boolean
        get() = p.getBoolean("adAll", true)
        set(v) = p.edit().putBoolean("adAll", v).apply()
    /** Reklam alan adlarını desenlerden otomatik algıla (ads.*, adserver*, doubleclick vb.). */
    var autoDetect: Boolean
        get() = p.getBoolean("autoDetect", true)
        set(v) = p.edit().putBoolean("autoDetect", v).apply()
    /** Topluluk reklam listelerini günde bir otomatik indir. */
    var autoList: Boolean
        get() = p.getBoolean("autoList", true)
        set(v) = p.edit().putBoolean("autoList", v).apply()
    var listVer: Int
        get() = p.getInt("listVer", 0)
        set(v) = p.edit().putInt("listVer", v).apply()
    var listUpdated: Long
        get() = p.getLong("listUpdated", 0L)
        set(v) = p.edit().putLong("listUpdated", v).apply()

    var includeBrowsers: Boolean
        get() = p.getBoolean("browsers", false)
        set(v) = p.edit().putBoolean("browsers", v).apply()

    val customBlocked: Set<String>
        get() = customBlockedRaw.lines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()

    /** Hızlı DNS'te kullanılan sağlayıcı. */
    val activeProvider: Provider get() = if (adblock) Providers.adguard else Providers.cloudflare
    fun upstreamIp(): String = activeProvider.ip
}

object Blocklist {
    val ads = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "adnxs.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net", "moatads.com",
        "adsrvr.org", "rubiconproject.com", "pubmatic.com", "openx.net", "amazon-adsystem.com",
        "unityads.unity3d.com", "applovin.com", "mopub.com", "inmobi.com", "startapp.com",
        "ads.yahoo.com", "advertising.com", "ads.tiktok.com", "adcolony.com", "vungle.com",
        "chartboost.com", "ironsrc.com", "supersonicads.com", "smaato.net", "adsafeprotected.com",
        "casalemedia.com", "yieldmo.com", "tapjoy.com", "fyber.com", "bidswitch.net", "adform.net",
        "smartadserver.com", "teads.tv", "media.net", "revcontent.com", "mgid.com", "zedo.com",
        "serving-sys.com", "2mdn.net", "adtechus.com", "contextweb.com", "lijit.com",
        "sharethrough.com", "33across.com", "indexww.com", "triplelift.com", "gumgum.com", "sovrn.com"
    )
    val trackers = setOf(
        "google-analytics.com", "googletagmanager.com", "googletagservices.com", "app-measurement.com",
        "scorecardresearch.com", "hotjar.com", "mixpanel.com", "appsflyer.com", "adjust.com", "branch.io",
        "analytics.tiktok.com", "bat.bing.com", "segment.io", "segment.com", "amplitude.com",
        "fullstory.com", "flurry.com", "kochava.com", "singular.net", "quantserve.com", "optimizely.com",
        "mouseflow.com", "crazyegg.com", "clarity.ms", "heapanalytics.com", "omtrdc.net", "demdex.net",
        "everesttech.net", "chartbeat.com", "comscore.com"
    )

    /** İndirilen topluluk listesi (AdAway, Peter Lowe, StevenBlack). */
    @Volatile var hosts: Set<String> = emptySet()

    // Uygulamaların çalışması için asla engellenmeyecek alan adları.
    private val protectedSuffixes = listOf(
        "roblox.com", "rbxcdn.com", "discord.com", "discordapp.com", "discordapp.net", "discord.gg", "discord.media"
    )
    // Etiketin içinde geçmesi reklam sunucusu olduğunu gösteren güçlü kalıplar.
    private val strongTokens = listOf("adserver", "adservice", "adsystem", "adtech", "adnetwork", "doubleclick", "googlead", "pagead", "adsrv")
    // ads, ad, adx, adv, ads1, ads-eu ... gibi alt alan adı etiketleri.
    private val adLabel = Regex("^(ads?|adx|adv)[0-9-]*$")

    /** Liste sürümü: kaynaklar değişince eski cihazlarda listeyi bir kez zorla yeniler. */
    const val VERSION = 2

    // Reklam, açılır pencere (popup) ve izleyici listeleri. Biri indirilemezse atlanır.
    private val sources = listOf(
        "https://adaway.org/hosts.txt",
        "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext",
        "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
        "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/hosts/pro.txt",
        "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/hosts/popupads.txt",
        "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt"
    )

    private val domainRe = Regex("^[a-z0-9]([a-z0-9._-]*[a-z0-9])?$")

    /** hosts, AdGuard (||alan^) ve düz alan adı satırlarından alan adını çıkarır. */
    private fun parseDomain(raw: String): String? {
        var line = raw.trim()
        if (line.isEmpty() || line[0] == '#' || line[0] == '!' || line.startsWith("@@")) return null
        line = line.substringBefore(" #").trim()
        val d0: String = if (line.startsWith("||")) {
            val r = line.substring(2)
            val end = r.indexOfFirst { it == '^' || it == '$' || it == '/' }
            (if (end >= 0) r.substring(0, end) else r)
        } else {
            val parts = line.split(Regex("\\s+"))
            when {
                parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1") -> parts[1]
                parts.size == 1 -> parts[0]
                else -> return null
            }
        }
        val d = d0.lowercase()
        if (d == "localhost" || !d.contains('.') || !domainRe.matches(d)) return null
        return d
    }

    @Volatile private var cacheRaw = ""
    @Volatile private var cacheSet: Set<String> = emptySet()
    private fun customSet(p: Prefs): Set<String> {
        val raw = p.customBlockedRaw
        if (raw != cacheRaw) { cacheSet = p.customBlocked; cacheRaw = raw }
        return cacheSet
    }

    private fun isProtected(d: String) = protectedSuffixes.any { d == it || d.endsWith(".$it") }

    /** Alan adı kalıbından reklam sunucusu olup olmadığını tahmin eder. */
    fun looksLikeAd(name: String): Boolean {
        val labels = name.split('.')
        if (labels.size < 2) return false
        for (l in labels) for (t in strongTokens) if (l.contains(t)) return true
        // Zayıf kalıplar yalnızca alt alan adlarında aranır (ör. ads.site.com), ana alan adında değil.
        val sub = if (labels.size > 2) labels.dropLast(2) else emptyList()
        for (l in sub) if (adLabel.matches(l)) return true
        return false
    }

    fun isBlocked(name: String, p: Prefs): Boolean {
        val custom = customSet(p)
        val prot = isProtected(name)
        val useAds = p.blockAds
        val useTr = p.blockTrackers
        val list = hosts
        var d = name
        while (true) {
            if (d in custom) return true
            if (!prot) {
                if (useAds && (d in ads || d in list)) return true
                if (useTr && d in trackers) return true
            }
            val i = d.indexOf('.')
            if (i < 0) break
            d = d.substring(i + 1)
        }
        return !prot && useAds && p.autoDetect && looksLikeAd(name)
    }

    private fun listFile(ctx: Context) = java.io.File(ctx.filesDir, "adhosts.txt")

    fun load(ctx: Context) {
        try {
            val f = listFile(ctx)
            if (f.exists()) hosts = f.readLines().filter { it.isNotEmpty() }.toHashSet()
        } catch (_: Exception) {}
    }

    /** Listeleri indirir ve kaydeder. Eklenen alan adı sayısını döndürür, başarısızsa -1. */
    fun update(ctx: Context, prefs: Prefs): Int {
        val out = HashSet<String>()
        var okAny = false
        for (u in sources) {
            try {
                val c = URL(u).openConnection() as HttpsURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.setRequestProperty("User-Agent", "RemiDNS")
                if (c.responseCode != 200) continue
                c.inputStream.bufferedReader().useLines { lines ->
                    for (raw in lines) parseDomain(raw)?.let { out.add(it) }
                }
                okAny = true
            } catch (_: Exception) {}
        }
        if (!okAny || out.size < 500) return -1
        out.removeAll { isProtected(it) }
        try { listFile(ctx).writeText(out.joinToString("\n")) } catch (_: Exception) {}
        hosts = out
        prefs.listUpdated = System.currentTimeMillis()
        prefs.listVer = VERSION
        return out.size
    }
}

/** Türkiye'de erişim engeli olan uygulamalar (varsayılan seçim) ve kullanıcının seçtiği uygulamalar. */
object Targets {
    val banned = listOf("com.roblox.client", "com.discord")

    /** Telefondaki başlatılabilir tüm uygulamalar (kendimiz hariç). */
    fun launchable(ctx: Context): List<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return ctx.packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != ctx.packageName }
    }

    /** Stok: hiç seçim yapılmadıysa TÜM uygulamalar korunur (sonradan kurulanlar da dahil). */
    fun vpnApps(ctx: Context): List<String> {
        val pm = ctx.packageManager
        val sel = Prefs(ctx).selectedRaw
        val found = if (sel == null) launchable(ctx)
        else sel.filter { try { pm.getPackageInfo(it, 0); true } catch (e: Exception) { false } }
        // Hiçbiri seçili değilse yalnızca kendi uygulamamız tünele girer (diğer uygulamalar etkilenmez).
        return if (found.isEmpty()) listOf(ctx.packageName) else found
    }
}

/** DoH ısınma sorgusu yardımcıları. */
object Bench {
    fun query(name: String): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
        for (part in name.split('.')) {
            val b = part.toByteArray()
            out.write(b.size)
            out.write(b)
        }
        out.write(0)
        out.write(byteArrayOf(0, 1, 0, 1))
        return out.toByteArray()
    }

    /** DoH sorgusu gönderir, yanıt süresini (ms) döndürür. */
    fun post(url: String, q: ByteArray): Long {
        val t0 = System.nanoTime()
        val c = URL(url).openConnection() as HttpsURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 3000
        c.readTimeout = 3000
        c.setRequestProperty("Content-Type", "application/dns-message")
        c.setRequestProperty("Accept", "application/dns-message")
        c.outputStream.use { it.write(q) }
        if (c.responseCode != 200) throw IOException("DoH ${c.responseCode}")
        c.inputStream.use { it.readBytes() }
        return (System.nanoTime() - t0) / 1_000_000
    }
}
