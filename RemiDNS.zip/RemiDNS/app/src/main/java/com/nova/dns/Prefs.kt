package com.nova.dns

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.URL
import javax.net.ssl.HttpsURLConnection

data class Provider(val name: String, val desc: String, val ip: String, val doh: String?)

object Providers {
    val all = listOf(
        Provider("Cloudflare", "1.1.1.1 · En hızlı, gizlilik odaklı", "1.1.1.1", "https://1.1.1.1/dns-query"),
        Provider("Cloudflare Güvenlik", "1.1.1.2 · Zararlı siteleri engeller", "1.1.1.2", "https://1.1.1.2/dns-query"),
        Provider("Cloudflare Aile", "1.1.1.3 · Zararlı + yetişkin içerik engeli", "1.1.1.3", "https://1.1.1.3/dns-query"),
        Provider("Google DNS", "8.8.8.8 · Kararlı ve güvenilir", "8.8.8.8", "https://8.8.8.8/dns-query"),
        Provider("Quad9", "9.9.9.9 · Gizlilik + tehdit koruması", "9.9.9.9", "https://9.9.9.9/dns-query"),
        Provider("AdGuard", "94.140.14.14 · Sağlayıcı seviyesinde reklam engeli", "94.140.14.14", "https://94.140.14.14/dns-query"),
        Provider("Özel DNS", "Kendi DNS adresini gir", "", null)
    )
}

class Prefs(c: Context) {
    private val p = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    var providerIdx: Int
        get() = p.getInt("prov", 0).coerceIn(0, Providers.all.size - 1)
        set(v) = p.edit().putInt("prov", v).apply()
    var doh: Boolean
        get() = p.getBoolean("doh", true)
        set(v) = p.edit().putBoolean("doh", v).apply()
    var adblock: Boolean
        get() = p.getBoolean("adblock", true)
        set(v) = p.edit().putBoolean("adblock", v).apply()
    var autostart: Boolean
        get() = p.getBoolean("autostart", false)
        set(v) = p.edit().putBoolean("autostart", v).apply()
    var customDns: String
        get() = p.getString("customDns", "") ?: ""
        set(v) = p.edit().putString("customDns", v).apply()
    var customBlockedRaw: String
        get() = p.getString("customBlocked", "") ?: ""
        set(v) = p.edit().putString("customBlocked", v).apply()

    var excluded: Set<String>
        get() = p.getStringSet("excluded", emptySet()) ?: emptySet()
        set(v) = p.edit().putStringSet("excluded", HashSet(v)).apply()

    var fullVpn: Boolean
        get() = p.getBoolean("fullVpn", true)
        set(v) = p.edit().putBoolean("fullVpn", v).apply()
    var wgCustom: String
        get() = p.getString("wgCustom", "") ?: ""
        set(v) = p.edit().putString("wgCustom", v).apply()
    var warpCfg: String
        get() = p.getString("warpCfg", "") ?: ""
        set(v) = p.edit().putString("warpCfg", v).apply()

    var warpEp: String
        get() = p.getString("warpEp", "") ?: ""
        set(v) = p.edit().putString("warpEp", v).apply()

    /** 0 = Hızlı DNS (sadece DNS yönlendirilir), 1 = Tam VPN (WARP). */
    var mode: Int
        get() = p.getInt("mode", 0)
        set(v) = p.edit().putInt("mode", v).apply()
    var autoDns: Boolean
        get() = p.getBoolean("autoDns", true)
        set(v) = p.edit().putBoolean("autoDns", v).apply()
    var blockAds: Boolean
        get() = p.getBoolean("blockAds", true)
        set(v) = p.edit().putBoolean("blockAds", v).apply()
    var blockTrackers: Boolean
        get() = p.getBoolean("blockTrackers", true)
        set(v) = p.edit().putBoolean("blockTrackers", v).apply()
    /** Kullanıcının seçtiği uygulamalar. null = henüz seçilmedi (varsayılan: Roblox + Discord). */
    var selectedRaw: Set<String>?
        get() = p.getStringSet("selected", null)
        set(v) = p.edit().putStringSet("selected", if (v == null) null else HashSet(v)).apply()

    var includeBrowsers: Boolean
        get() = p.getBoolean("browsers", false)
        set(v) = p.edit().putBoolean("browsers", v).apply()

    val provider: Provider get() = Providers.all[providerIdx]
    val customBlocked: Set<String>
        get() = customBlockedRaw.lines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()

    fun upstreamIp(): String {
        val pr = provider
        return if (pr.ip.isEmpty()) customDns.trim().ifEmpty { "1.1.1.1" } else pr.ip
    }
}

object Blocklist {
    val ads = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "adnxs.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net", "moatads.com",
        "adsrvr.org", "rubiconproject.com", "pubmatic.com", "openx.net", "amazon-adsystem.com",
        "unityads.unity3d.com", "applovin.com", "mopub.com", "inmobi.com", "startapp.com",
        "ads.yahoo.com", "advertising.com", "ads.tiktok.com", "adcolony.com", "vungle.com",
        "chartboost.com", "ironsrc.com", "supersonicads.com", "smaato.net", "adsafeprotected.com",
        "casalemedia.com", "yieldmo.com", "tapjoy.com", "fyber.com", "bidswitch.net", "adform.net",
        "smartadserver.com", "teads.tv", "media.net", "revcontent.com", "mgid.com", "zedo.com",
        "serving-sys.com", "2mdn.net", "adtechus.com", "contextweb.com", "lijit.com",
        "sharethrough.com", "33across.com", "indexww.com", "triplelift.com", "gumgum.com", "sovrn.com"
    )
    val trackers = setOf(
        "google-analytics.com", "googletagmanager.com", "googletagservices.com", "app-measurement.com",
        "scorecardresearch.com", "hotjar.com", "mixpanel.com", "appsflyer.com", "adjust.com", "branch.io",
        "analytics.tiktok.com", "bat.bing.com", "segment.io", "segment.com", "amplitude.com",
        "fullstory.com", "flurry.com", "kochava.com", "singular.net", "quantserve.com", "optimizely.com",
        "mouseflow.com", "crazyegg.com", "clarity.ms", "heapanalytics.com", "omtrdc.net", "demdex.net",
        "everesttech.net", "chartbeat.com", "comscore.com"
    )

    @Volatile private var cacheRaw = ""
    @Volatile private var cacheSet: Set<String> = emptySet()
    private fun customSet(p: Prefs): Set<String> {
        val raw = p.customBlockedRaw
        if (raw != cacheRaw) { cacheSet = p.customBlocked; cacheRaw = raw }
        return cacheSet
    }

    fun isBlocked(name: String, p: Prefs): Boolean {
        val custom = customSet(p)
        val useAds = p.blockAds
        val useTr = p.blockTrackers
        var d = name
        while (true) {
            if (d in custom) return true
            if (useAds && d in ads) return true
            if (useTr && d in trackers) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }
}

/** Türkiye'de erişim engeli olan uygulamalar (varsayılan seçim) ve kullanıcının seçtiği uygulamalar. */
object Targets {
    val banned = listOf("com.roblox.client", "com.discord")

    fun vpnApps(ctx: Context): List<String> {
        val pm = ctx.packageManager
        val want = Prefs(ctx).selectedRaw ?: banned.toSet()
        val found = want.filter { try { pm.getPackageInfo(it, 0); true } catch (e: Exception) { false } }
        // Hiçbiri seçili/kurulu değilse yalnızca kendi uygulamamız tünele girer (diğer uygulamalar etkilenmez).
        return if (found.isEmpty()) listOf(ctx.packageName) else found
    }
}

/** DNS sağlayıcı hız testi (DoH gecikmesi). Otomatik seçim yalnızca filtresiz sağlayıcılar arasında yapılır. */
object Bench {
    val candidates = listOf(0, 3, 4) // Cloudflare, Google, Quad9

    fun query(name: String): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
        for (part in name.split('.')) {
            val b = part.toByteArray()
            out.write(b.size)
            out.write(b)
        }
        out.write(0)
        out.write(byteArrayOf(0, 1, 0, 1))
        return out.toByteArray()
    }

    /** DoH sorgusu gönderir, yanıt süresini (ms) döndürür. */
    fun post(url: String, q: ByteArray): Long {
        val t0 = System.nanoTime()
        val c = URL(url).openConnection() as HttpsURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 3000
        c.readTimeout = 3000
        c.setRequestProperty("Content-Type", "application/dns-message")
        c.setRequestProperty("Accept", "application/dns-message")
        c.outputStream.use { it.write(q) }
        if (c.responseCode != 200) throw IOException("DoH ${c.responseCode}")
        c.inputStream.use { it.readBytes() }
        return (System.nanoTime() - t0) / 1_000_000
    }

    private fun measure(url: String): Long = try {
        post(url, query("example.com"))           // ısınma (TLS el sıkışması)
        post(url, query("roblox.com"))            // gerçek, kararlı gecikme
    } catch (e: Exception) { Long.MAX_VALUE }

    fun run(): List<Pair<Int, Long>> {
        val res = java.util.concurrent.ConcurrentHashMap<Int, Long>()
        val ts = candidates.map { i -> Thread { res[i] = measure(Providers.all[i].doh ?: "") }.also { it.start() } }
        ts.forEach { it.join(8000) }
        return candidates.map { Pair(it, res[it] ?: Long.MAX_VALUE) }.sortedBy { it.second }
    }

    fun fastest(): Int = run().firstOrNull { it.second != Long.MAX_VALUE }?.first ?: -1
}
