package com.nova.dns

import android.content.Context
import android.content.Intent

/** WARP tüneli içinde kullanılan DNS sağlayıcıları (hızlı geçiş: Cloudflare <-> AdGuard). */
enum class DnsChoice(val label: String, val servers: String, val desc: String) {
    CLOUDFLARE("Cloudflare", "1.1.1.1, 1.0.0.1", "Cloudflare 1.1.1.1 · hızlı, reklam engelleme yok"),
    ADGUARD("AdGuard", "94.140.14.14, 94.140.15.15", "AdGuard DNS · reklam ve izleyici engelleme açık");

    companion object {
        fun of(i: Int) = values().getOrElse(i) { CLOUDFLARE }
    }
}

class Prefs(c: Context) {
    private val p = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    var autostart: Boolean
        get() = p.getBoolean("autostart", false)
        set(v) = p.edit().putBoolean("autostart", v).apply()

    var wgCustom: String
        get() = p.getString("wgCustom", "") ?: ""
        set(v) = p.edit().putString("wgCustom", v).apply()
    var warpCfg: String
        get() = p.getString("warpCfg", "") ?: ""
        set(v) = p.edit().putString("warpCfg", v).apply()
    var warpEp: String
        get() = p.getString("warpEp", "") ?: ""
        set(v) = p.edit().putString("warpEp", v).apply()

    /** Otomatik: tarayıcıda AdGuard, uygulama/oyunlarda Cloudflare. */
    var dnsAuto: Boolean
        get() = p.getBoolean("dnsAuto", true)
        set(v) = p.edit().putBoolean("dnsAuto", v).apply()

    /** Tünel DNS'i (otomatik modda şu an geçerli olan): 0 = Cloudflare, 1 = AdGuard. */
    var dns: DnsChoice
        get() = DnsChoice.of(p.getInt("dns", 0))
        set(v) = p.edit().putInt("dns", v.ordinal).apply()

    /** Kullanıcının seçtiği uygulamalar. null = henüz seçilmedi (varsayılan: tüm uygulamalar). */
    var selectedRaw: Set<String>?
        get() = p.getStringSet("selected", null)
        set(v) = p.edit().putStringSet("selected", if (v == null) null else HashSet(v)).apply()
}

/** Türkiye'de erişim engeli olan uygulamalar (listede öne çıkarılır) ve kullanıcının seçtiği uygulamalar. */
object Targets {
    val banned = listOf("com.roblox.client", "com.discord")

    /** Telefondaki başlatılabilir tüm uygulamalar (kendimiz hariç). */
    fun launchable(ctx: Context): List<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return ctx.packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != ctx.packageName }
    }

    /** Hiç seçim yapılmadıysa TÜM uygulamalar tünele girer (sonradan kurulanlar da dahil). */
    fun vpnApps(ctx: Context): List<String> {
        val pm = ctx.packageManager
        val sel = Prefs(ctx).selectedRaw
        val found = if (sel == null) launchable(ctx)
        else sel.filter { try { pm.getPackageInfo(it, 0); true } catch (e: Exception) { false } }
        // Hiçbiri seçili değilse yalnızca kendi uygulamamız tünele girer (diğer uygulamalar etkilenmez).
        return if (found.isEmpty()) listOf(ctx.packageName) else found
    }
}
