package com.remidns.app

import com.wireguard.crypto.KeyPair
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class Registration(val config: String, val id: String, val token: String)

/** Cloudflare WARP'a ücretsiz hesap açar, WireGuard yapılandırma metni üretir, WARP+ anahtarı uygular. */
object WarpRegistrar {
    // Resmi olmayan API. Çalışmazsa sürüm numarasını (v0a2158 / a-6.3-2158) güncelle.
    private const val BASE = "https://api.cloudflareclient.com/v0a2158/reg"
    private const val CLIENT_VERSION = "a-6.3-2158"
    private const val PEER_PUBLIC_KEY = "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo="
    // Alan adı yerine IP: DNS engeline takılmasın diye.
    private const val ENDPOINT = "162.159.192.1:2408"

    private fun open(url: String, method: String, token: String? = null): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("User-Agent", "okhttp/3.12.1")
        c.setRequestProperty("CF-Client-Version", CLIENT_VERSION)
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        return c
    }

    private fun send(c: HttpURLConnection, body: JSONObject): String {
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.readText().orEmpty()
        if (code !in 200..299) throw IOException("HTTP $code")
        return text
    }

    fun register(): Registration {
        val keys = KeyPair()
        val tos = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())

        val body = JSONObject()
            .put("key", keys.publicKey.toBase64())
            .put("install_id", "")
            .put("fcm_token", "")
            .put("tos", tos)
            .put("model", "Android")
            .put("serial_number", "")
            .put("locale", "en_US")

        val text = try { send(open(BASE, "POST"), body) }
        catch (e: IOException) { throw IOException("WARP kaydı başarısız (${e.message})") }

        val json = JSONObject(text)
        val addrs = json.getJSONObject("config").getJSONObject("interface").getJSONObject("addresses")
        val v4 = addrs.getString("v4")
        val v6 = addrs.getString("v6")

        val cfg = """
            [Interface]
            PrivateKey = ${keys.privateKey.toBase64()}
            Address = $v4/32, $v6/128
            DNS = 1.1.1.1, 1.0.0.1
            MTU = 1280

            [Peer]
            PublicKey = $PEER_PUBLIC_KEY
            AllowedIPs = 0.0.0.0/0, ::/0
            Endpoint = $ENDPOINT
            PersistentKeepalive = 25
        """.trimIndent()
        return Registration(cfg, json.getString("id"), json.getString("token"))
    }

    /** Kendi satın aldığın / sana verilen WARP+ lisans anahtarını hesaba bağlar. */
    fun applyLicense(id: String, token: String, license: String) {
        try {
            send(open("$BASE/$id/account", "PUT", token), JSONObject().put("license", license))
        } catch (e: IOException) {
            throw IOException("Anahtar kabul edilmedi (${e.message})")
        }
    }
}
