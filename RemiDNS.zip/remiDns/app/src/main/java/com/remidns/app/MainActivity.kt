package com.remidns.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.VpnService
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream
import java.io.IOException

class MainActivity : Activity() {

    companion object {
        private var backend: GoBackend? = null
        private val tunnel = object : Tunnel {
            override fun getName(): String = "remidns"
            override fun onStateChange(newState: Tunnel.State) {}
        }
        private const val REQ_VPN = 1
        // Cloudflare'ın WARP için kabul ettiği UDP portları; biri yavaş/engelliyse sıradakine geçilir.
        private val PORTS = listOf(2408, 500, 1701, 4500)
        private const val GAME_APPS = "com.roblox.client, com.discord"
    }

    private lateinit var status: TextView
    private lateinit var button: Button
    private lateinit var manual: EditText
    private lateinit var licenseBox: EditText
    private lateinit var split: Switch
    private var connected = false
    private var busy = false

    private val ink = Color.parseColor("#14173A")
    private val accent = Color.parseColor("#7B7BFF")
    private val muted = Color.parseColor("#9EA4CF")
    private val prefs by lazy { getSharedPreferences("remidns", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (backend == null) backend = GoBackend(applicationContext)
        buildUi()
        refresh()
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(muted); setPadding(0, dp(24), 0, dp(8))
    }

    private fun box(hint: String, lines: Int) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(Color.parseColor("#5A5F80"))
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.TOP; minLines = lines
        setBackgroundColor(Color.parseColor("#1A1D40"))
        setPadding(dp(12), dp(12), dp(12), dp(12))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(32))
        }
        root.addView(TextView(this).apply {
            text = "remiDns"; textSize = 44f; setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        })
        status = TextView(this).apply {
            text = "Bağlı değil"; textSize = 18f; setTextColor(muted)
            setPadding(0, dp(8), 0, dp(28))
        }
        root.addView(status)

        button = Button(this).apply {
            text = "Bağlan"; textSize = 18f; setTextColor(ink); setBackgroundColor(accent)
            setOnClickListener { toggle() }
        }
        root.addView(button, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)))

        split = Switch(this).apply {
            text = "Hız modu: sadece Roblox ve Discord VPN'den geçsin"
            setTextColor(Color.WHITE); textSize = 14f
            isChecked = prefs.getBoolean("split", false)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("split", v).apply() }
            setPadding(0, dp(24), 0, 0)
        }
        root.addView(split)
        root.addView(TextView(this).apply {
            text = "Diğer uygulamalar normal bağlantıdan gider, böylece oyun daha az gecikir. Değişiklik için yeniden bağlan."
            textSize = 12f; setTextColor(muted)
        })

        root.addView(label("WARP+ lisans anahtarın varsa gir (1.1.1.1 uygulamasından satın aldığın veya sana verilen):"))
        licenseBox = box("xxxxxxxx-xxxxxxxx-xxxxxxxx", 1)
        root.addView(licenseBox)
        root.addView(Button(this).apply {
            text = "Anahtarı uygula"; textSize = 13f
            setOnClickListener { applyLicense() }
        })

        root.addView(label("Kendi WireGuard yapılandırmanı kullanmak istersen yapıştır (boşsa WARP hesabı otomatik açılır):"))
        manual = box("[Interface] ...", 5)
        root.addView(manual)
        root.addView(Button(this).apply {
            text = "Kayıtlı WARP hesabını sıfırla"; textSize = 13f
            setOnClickListener {
                prefs.edit().remove("cfg").remove("id").remove("token").apply()
                status.text = "Hesap sıfırlandı, tekrar bağlan"
            }
        })

        setContentView(android.widget.ScrollView(this).apply {
            setBackgroundColor(ink); isFillViewport = true; addView(root)
        })
    }

    private fun render(up: Boolean) {
        connected = up; busy = false; button.isEnabled = true
        button.text = if (up) "Bağlantıyı kes" else "Bağlan"
        status.text = if (up) "Bağlı · WARP" else "Bağlı değil"
    }

    private fun refresh() {
        Thread {
            val up = try { backend!!.getState(tunnel) == Tunnel.State.UP } catch (e: Exception) { false }
            runOnUiThread { render(up) }
        }.start()
    }

    private fun toggle() {
        if (busy) return
        if (connected) { disconnect(); return }
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, REQ_VPN) else connect()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) connect() else status.text = "VPN izni verilmedi"
        }
    }

    /** Kayıtlı WARP hesabını döndürür, yoksa yeni açar. */
    private fun ensureAccount(): String {
        prefs.getString("cfg", null)?.let { return it }
        val r = WarpRegistrar.register()
        prefs.edit().putString("cfg", r.config).putString("id", r.id).putString("token", r.token).apply()
        return r.config
    }

    private fun applyLicense() {
        val key = licenseBox.text.toString().trim()
        if (key.isEmpty()) { status.text = "Önce anahtarı gir"; return }
        status.text = "Anahtar uygulanıyor…"
        Thread {
            try {
                ensureAccount()
                WarpRegistrar.applyLicense(prefs.getString("id", "")!!, prefs.getString("token", "")!!, key)
                runOnUiThread { status.text = "WARP+ anahtarı uygulandı, yeniden bağlan" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Hata: ${e.message}" }
            }
        }.start()
    }

    private fun connect() {
        busy = true
        button.isEnabled = false
        status.text = "Bağlanıyor…"
        val pasted = manual.text.toString().trim()
        val onlyGames = split.isChecked
        Thread {
            try {
                val base = if (pasted.isNotEmpty()) pasted else ensureAccount()
                // Yapıştırılan yapılandırma olduğu gibi kullanılır; WARP hesabında port otomatik seçilir.
                val ports: List<Int?> = if (pasted.isNotEmpty()) listOf(null) else PORTS
                var ok = false
                for (p in ports) {
                    var text = base
                    if (p != null) {
                        text = text.replace(Regex("Endpoint = ([^:\\s]+):\\d+"), "Endpoint = $1:$p")
                        if (onlyGames) text = text.replace("MTU = 1280", "MTU = 1280\nIncludedApplications = $GAME_APPS")
                        runOnUiThread { status.text = "Bağlanıyor… (port $p)" }
                    }
                    val cfg = Config.parse(ByteArrayInputStream(text.toByteArray()))
                    backend!!.setState(tunnel, Tunnel.State.UP, cfg)
                    if (p == null) { ok = true; break }
                    Thread.sleep(3500)
                    if (backend!!.getStatistics(tunnel).totalRx() > 0) { ok = true; break }
                    backend!!.setState(tunnel, Tunnel.State.DOWN, null)
                }
                if (!ok) throw IOException("Hiçbir port yanıt vermedi")
                runOnUiThread { render(true) }
            } catch (e: Exception) {
                runOnUiThread {
                    render(false)
                    status.text = "Hata: ${e.message ?: e.javaClass.simpleName}"
                }
            }
        }.start()
    }

    private fun disconnect() {
        busy = true
        button.isEnabled = false
        Thread {
            try { backend!!.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
            runOnUiThread { render(false) }
        }.start()
    }
}
