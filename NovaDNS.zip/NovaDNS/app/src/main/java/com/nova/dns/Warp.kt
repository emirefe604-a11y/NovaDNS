package com.nova.dns

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.crypto.KeyPair
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.IOException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.net.ssl.HttpsURLConnection

/** Tam VPN modu: Cloudflare WARP (WireGuard) tüneli. Tüm trafik tünelden geçer. */
object Warp {
    @Volatile var active = false
    @Volatile var connecting = false
    @Volatile var error = ""
    private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName() = "warp"
        override fun onStateChange(newState: Tunnel.State) { active = newState == Tunnel.State.UP }
    }

    // Cloudflare WARP uç noktaları: biri/portu engelliyse sıradakine otomatik geçer.
    private val endpoints = listOf(
        "162.159.192.1:2408", "162.159.192.1:500", "162.159.192.1:4500", "162.159.193.1:2408"
    )

    fun connect(ctx: Context) {
        val app = ctx.applicationContext
        Thread {
            connecting = true
            error = ""
            try {
                val prefs = Prefs(app)
                val custom = prefs.wgCustom.trim().isNotEmpty()
                var cfg = prefs.wgCustom.trim()
                if (cfg.isEmpty()) {
                    cfg = prefs.warpCfg
                    if (cfg.isEmpty()) { cfg = register(); prefs.warpCfg = cfg }
                }
                val apps = Targets.vpnApps(app, prefs.includeBrowsers)
                val b = backend ?: GoBackend(app).also { backend = it }
                var ok = false
                for (ep in (if (custom) listOf<String?>(null) else endpoints)) {
                    val c0 = if (ep != null) cfg.replace(Regex("""(?m)^Endpoint\s*=.*$"""), "Endpoint = $ep") else cfg
                    b.setState(tunnel, Tunnel.State.UP, Config.parse(ByteArrayInputStream(tune(c0, apps, !custom).toByteArray())))
                    if (ep == null) { ok = true; break }
                    var n = 0
                    while (n < 12 && !ok) {
                        Thread.sleep(400)
                        n++
                        ok = try { b.getStatistics(tunnel).totalRx() > 0 } catch (e: Exception) { false }
                    }
                    if (ok) break
                    b.setState(tunnel, Tunnel.State.DOWN, null)
                }
                if (!ok) error = "Sunucuya ulaşılamadı. Başka bir ağ (Wi-Fi / mobil veri) dene."
            } catch (e: Exception) {
                error = "Hata: ${e.message ?: e.javaClass.simpleName}"
            }
            connecting = false
        }.start()
    }

    fun disconnect() {
        Thread {
            try { backend?.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
            active = false
        }.start()
    }

    private fun tune(cfg0: String, apps: List<String>, auto: Boolean): String {
        var cfg = cfg0.trimEnd() + "\n"
        if (auto) {
            // Hız ayarı: daha büyük MTU = daha az paket, daha yüksek verim; iki hızlı DNS.
            cfg = cfg.replace(Regex("""(?m)^MTU\s*=.*$"""), "MTU = 1380")
            cfg = cfg.replace(Regex("""(?m)^DNS\s*=.*$"""), "DNS = 1.1.1.1, 1.0.0.1")
        }
        if (!cfg.contains("PersistentKeepalive")) cfg += "PersistentKeepalive = 25\n"
        if (apps.isEmpty() || cfg.contains("IncludedApplications") || cfg.contains("ExcludedApplications")) return cfg
        return cfg.replaceFirst("[Interface]", "[Interface]\nIncludedApplications = " + apps.joinToString(", "))
    }

    /** Cloudflare WARP için ücretsiz hesap kaydı (wgcf ile aynı yöntem). */
    private fun register(): String {
        val kp = KeyPair()
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val body = JSONObject()
            .put("key", kp.publicKey.toBase64())
            .put("install_id", "")
            .put("fcm_token", "")
            .put("tos", fmt.format(Date()))
            .put("type", "Android")
            .put("model", "PC")
            .put("locale", "en_US")
        val c = URL("https://api.cloudflareclient.com/v0a1922/reg").openConnection() as HttpsURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 10000
        c.readTimeout = 10000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("User-Agent", "okhttp/3.12.1")
        c.setRequestProperty("CF-Client-Version", "a-6.3-2596")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) throw IOException("WARP kaydı başarısız (${c.responseCode})")
        val resp = JSONObject(c.inputStream.use { String(it.readBytes()) })
        val cfg = resp.getJSONObject("config")
        val peer = cfg.getJSONArray("peers").getJSONObject(0)
        val pub = peer.getString("public_key")
        val addrs = cfg.getJSONObject("interface").getJSONObject("addresses")
        val v6 = addrs.optString("v6", "")
        val addr = addrs.getString("v4") + "/32" + (if (v6.isNotEmpty()) ", $v6/128" else "")
        val allowed = if (v6.isNotEmpty()) "0.0.0.0/0, ::/0" else "0.0.0.0/0"
        return "[Interface]\n" +
            "PrivateKey = ${kp.privateKey.toBase64()}\n" +
            "Address = $addr\n" +
            "DNS = 1.1.1.1, 1.0.0.1\n" +
            "MTU = 1380\n\n" +
            "[Peer]\n" +
            "PublicKey = $pub\n" +
            "AllowedIPs = $allowed\n" +
            "Endpoint = 162.159.192.1:2408\n"
    }
}
