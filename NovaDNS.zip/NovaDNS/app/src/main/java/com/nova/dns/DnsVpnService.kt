package com.nova.dns

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.HttpsURLConnection

/**
 * DNS-only VPN: sadece sahte DNS adresine (10.111.222.2) giden trafik TUN'a yönlendirilir,
 * sorgular DoH veya UDP ile seçilen sağlayıcıya iletilir. Diğer trafik normal gider.
 */
class DnsVpnService : VpnService() {
    companion object {
        const val ACTION_STOP = "com.nova.dns.STOP"
        const val FAKE_DNS = "10.111.222.2"
        @Volatile var active = false
        val total = AtomicInteger()
        val blockedCount = AtomicInteger()
        val cache = java.util.concurrent.ConcurrentHashMap<String, Pair<ByteArray, Long>>()
        @Volatile var dohFailUntil = 0L
        val log: MutableList<String> = java.util.Collections.synchronizedList(ArrayList())
    }

    private var tun: ParcelFileDescriptor? = null
    private var pool: ExecutorService? = null
    @Volatile private var running = false
    private lateinit var prefs: Prefs

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn(); return START_NOT_STICKY
        }
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (running) return
        prefs = Prefs(this)
        cache.clear()
        dohFailUntil = 0L
        val b = Builder()
            .setSession("Nova DNS")
            .addAddress("10.111.222.1", 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .setMtu(1500)
            .setBlocking(true)
        for (pkg in Targets.vpnApps(this, prefs.includeBrowsers)) {
            try { b.addAllowedApplication(pkg) } catch (_: Exception) {}
        }
        val fd = b.establish()
        if (fd == null) { stopSelf(); return }
        tun = fd
        running = true
        active = true
        pool = Executors.newFixedThreadPool(16)
        Thread { loop(fd) }.start()
    }

    private fun stopVpn() {
        running = false
        active = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        pool?.shutdownNow()
        stopSelf()
    }

    override fun onRevoke() { stopVpn() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }

    private fun loop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        while (running) {
            val n = try { input.read(buf) } catch (e: IOException) { break }
            if (n <= 0) continue
            val pkt = buf.copyOf(n)
            try { pool?.execute { handle(pkt, output) } } catch (_: Exception) { break }
        }
    }

    private fun handle(pkt: ByteArray, output: FileOutputStream) {
        try {
            if (pkt.size < 28 || (pkt[0].toInt() shr 4) != 4) return
            val ihl = (pkt[0].toInt() and 0x0F) * 4
            if (pkt[9].toInt() != 17 || pkt.size < ihl + 8) return
            val dport = ((pkt[ihl + 2].toInt() and 0xFF) shl 8) or (pkt[ihl + 3].toInt() and 0xFF)
            if (dport != 53) return
            val ulen = ((pkt[ihl + 4].toInt() and 0xFF) shl 8) or (pkt[ihl + 5].toInt() and 0xFF)
            val end = minOf(pkt.size, ihl + ulen)
            if (end <= ihl + 8 + 12) return
            val query = pkt.copyOfRange(ihl + 8, end)

            val q = question(query)
            total.incrementAndGet()
            val reply: ByteArray? =
                if (q != null && prefs.adblock && Blocklist.isBlocked(q.first, prefs.customBlocked)) {
                    blockedCount.incrementAndGet()
                    addLog("✗ ${q.first}")
                    nxdomain(query, q.second)
                } else {
                    addLog("✓ ${q?.first ?: "?"}")
                    forward(query)
                }
            if (reply != null) writeReply(pkt, ihl, reply, output)
        } catch (_: Exception) {}
    }

    private fun addLog(s: String) {
        synchronized(log) {
            log.add(s)
            while (log.size > 200) log.removeAt(0)
        }
    }

    private fun question(q: ByteArray): Pair<String, Int>? {
        var i = 12
        val sb = StringBuilder()
        while (i < q.size) {
            val l = q[i].toInt() and 0xFF
            if (l == 0) {
                val end = i + 1 + 4
                return if (end <= q.size) Pair(sb.toString().lowercase(), end) else null
            }
            if (l >= 0xC0 || i + 1 + l > q.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(q, i + 1, l, Charsets.ISO_8859_1))
            i += l + 1
        }
        return null
    }

    private fun nxdomain(q: ByteArray, end: Int): ByteArray {
        val r = q.copyOf(end)
        r[2] = 0x81.toByte()
        r[3] = 0x83.toByte()
        for (k in 6..11) r[k] = 0
        return r
    }

    private fun forward(query: ByteArray): ByteArray? {
        val key = String(query, 2, query.size - 2, Charsets.ISO_8859_1)
        val now = System.currentTimeMillis()
        val hit = cache[key]
        if (hit != null) {
            if (hit.second > now) {
                val c = hit.first.copyOf()
                c[0] = query[0]; c[1] = query[1]
                return c
            }
            cache.remove(key)
        }
        val r = forwardNet(query) ?: return null
        val rcode = r[3].toInt() and 0x0F
        val answers = ((r[6].toInt() and 0xFF) shl 8) or (r[7].toInt() and 0xFF)
        if (r.size > 12 && rcode == 0 && answers > 0) {
            if (cache.size > 2000) cache.clear()
            cache[key] = Pair(r, now + 60_000)
        }
        return r
    }

    private fun forwardNet(query: ByteArray): ByteArray? {
        val p = prefs.provider
        if (prefs.doh && p.doh != null && System.currentTimeMillis() > dohFailUntil) {
            try { return doh(p.doh, query) } catch (_: Exception) {
                dohFailUntil = System.currentTimeMillis() + 60_000
            }
        }
        return try { udp(prefs.upstreamIp(), query) } catch (_: Exception) { null }
    }

    // IP adresiyle bağlanıldığı için sistem DNS'ine (kendimize) bağımlılık yok.
    private fun doh(url: String, q: ByteArray): ByteArray {
        val c = URL(url).openConnection() as HttpsURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 4000
        c.readTimeout = 4000
        c.setRequestProperty("Content-Type", "application/dns-message")
        c.setRequestProperty("Accept", "application/dns-message")
        c.outputStream.use { it.write(q) }
        if (c.responseCode != 200) throw IOException("DoH ${c.responseCode}")
        return c.inputStream.use { it.readBytes() }
    }

    private fun udp(ip: String, q: ByteArray): ByteArray {
        val s = DatagramSocket()
        try {
            protect(s)
            s.soTimeout = 4000
            s.connect(InetAddress.getByName(ip), 53)
            s.send(DatagramPacket(q, q.size))
            val b = ByteArray(4096)
            val r = DatagramPacket(b, b.size)
            s.receive(r)
            return b.copyOf(r.length)
        } finally {
            s.close()
        }
    }

    private fun writeReply(pkt: ByteArray, ihl: Int, reply: ByteArray, output: FileOutputStream) {
        val total = ihl + 8 + reply.size
        val out = ByteArray(total)
        System.arraycopy(pkt, 0, out, 0, ihl)
        System.arraycopy(pkt, 16, out, 12, 4)
        System.arraycopy(pkt, 12, out, 16, 4)
        out[2] = (total shr 8).toByte(); out[3] = total.toByte()
        out[8] = 64
        out[10] = 0; out[11] = 0
        var sum = 0
        var i = 0
        while (i < ihl) {
            sum += ((out[i].toInt() and 0xFF) shl 8) or (out[i + 1].toInt() and 0xFF)
            i += 2
        }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val ck = sum.inv() and 0xFFFF
        out[10] = (ck shr 8).toByte(); out[11] = ck.toByte()

        out[ihl] = pkt[ihl + 2]; out[ihl + 1] = pkt[ihl + 3]
        out[ihl + 2] = pkt[ihl]; out[ihl + 3] = pkt[ihl + 1]
        val ul = 8 + reply.size
        out[ihl + 4] = (ul shr 8).toByte(); out[ihl + 5] = ul.toByte()
        out[ihl + 6] = 0; out[ihl + 7] = 0
        System.arraycopy(reply, 0, out, ihl + 8, reply.size)
        synchronized(output) { output.write(out) }
    }
}
