package com.nova.dns

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

object C {
    val BG = 0xFF0B1020.toInt()
    val BG2 = 0xFF1B1245.toInt()
    val CARD = 0xFF151B30.toInt()
    val FIELD = 0xFF0E1328.toInt()
    val STROKE = 0xFF283052.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val MUTED = 0xFF8A93B2.toInt()
    val ACCENT = 0xFF6C5CE7.toInt()
    val ACCENT2 = 0xFF8E7CFF.toInt()
    val GREEN = 0xFF2ED573.toInt()
    val TEAL = 0xFF00D2D3.toInt()
    val SEL = 0x336C5CE7
}

class PowerButton(c: Context) : View(c) {
    private var on = false
    private var busy = false
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    fun setState(active: Boolean, connecting: Boolean) {
        if (active != on || connecting != busy) { on = active; busy = connecting; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val breathe = 1f + 0.03f * sin(t * 2f * PI.toFloat())
        val r = minOf(width, height) / 2f * 0.58f * breathe
        p.shader = null
        p.style = Paint.Style.FILL
        if (on) {
            for (k in 0..1) {
                val ph = (t + k * 0.5f) % 1f
                p.color = Color.argb((80 * (1 - ph)).toInt(), 46, 213, 115)
                c.drawCircle(cx, cy, r * (1f + 0.65f * ph), p)
            }
        }
        p.color = if (on) 0x222ED573 else 0x226C5CE7
        c.drawCircle(cx, cy, r * 1.22f, p)
        p.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            if (on) C.GREEN else C.ACCENT, if (on) C.TEAL else C.ACCENT2, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        if (busy) {
            p.strokeWidth = r * 0.09f
            p.color = C.TEAL
            val ring = r * 1.3f
            c.drawArc(RectF(cx - ring, cy - ring, cx + ring, cy + ring), t * 360f, 110f, false, p)
            p.color = C.ACCENT2
            c.drawArc(RectF(cx - ring, cy - ring, cx + ring, cy + ring), t * 360f + 180f, 60f, false, p)
        }
        p.strokeWidth = r * 0.13f
        p.color = Color.WHITE
        val ir = r * 0.42f
        c.drawArc(RectF(cx - ir, cy - ir, cx + ir, cy + ir), -60f, 300f, false, p)
        c.drawLine(cx, cy - ir * 1.2f, cx, cy - ir * 0.05f, p)
    }
}

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private val h = Handler(Looper.getMainLooper())
    private lateinit var power: PowerButton
    private lateinit var titleTv: TextView
    private lateinit var sub: TextView
    private lateinit var qNum: TextView
    private lateinit var bNum: TextView
    private lateinit var logv: TextView
    private val provRows = ArrayList<LinearLayout>()
    private val provDots = ArrayList<View>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int = 0, strokeColor: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke > 0) setStroke(dp(stroke), strokeColor)
        }

    private fun tv(t: String, size: Float, color: Int = C.TEXT, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun lp(top: Int = 0, bottom: Int = 0, w: Int = -1, h: Int = -2, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(C.CARD, 18, 1, C.STROKE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun section(t: String) = tv(t.uppercase(), 12f, C.MUTED, true).apply {
        letterSpacing = 0.1f
        setPadding(dp(4), 0, 0, 0)
    }

    private fun switchRow(title: String, desc: String, init: Boolean, premium: Boolean, on: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(tv(title, 15f, bold = true))
        if (premium) {
            head.addView(
                tv("PREMIUM", 9f, Color.WHITE, true).apply {
                    background = shape(C.ACCENT, 6)
                    setPadding(dp(6), dp(2), dp(6), dp(2))
                },
                lp(w = -2).apply { leftMargin = dp(8) }
            )
        }
        col.addView(head)
        col.addView(tv(desc, 12f, C.MUTED))
        row.addView(col, lp(w = 0, weight = 1f))
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val sw = Switch(this).apply {
            isChecked = init
            trackTintList = ColorStateList(states, intArrayOf(C.ACCENT, C.STROKE))
            thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, C.MUTED))
            setOnCheckedChangeListener { _, c -> on(c) }
        }
        row.addView(sw)
        return row
    }

    private fun field(hintText: String, init: String, lines: Int): EditText = EditText(this).apply {
        setHint(hintText)
        setText(init)
        setTextColor(C.TEXT)
        setHintTextColor(C.MUTED)
        textSize = 14f
        background = shape(C.FIELD, 12, 1, C.STROKE)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        if (lines > 1) {
            minLines = lines
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        } else {
            setSingleLine()
        }
    }

    private fun refreshProviders() {
        provRows.forEachIndexed { i, r ->
            val sel = i == prefs.providerIdx
            r.background = shape(if (sel) C.SEL else 0x00000000, 12, 1, if (sel) C.ACCENT else C.STROKE)
            provDots[i].background = if (sel) shape(C.ACCENT, 9) else shape(0x00000000, 9, 2, C.MUTED)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.BG, C.BG2)))
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG2

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(28))
        }

        // Başlık
        root.addView(tv("Nova DNS", 28f, bold = true))
        root.addView(tv("Hızlı  •  Güvenli  •  Reklamsız", 13f, C.MUTED))

        // Güç düğmesi
        power = PowerButton(this).apply { setOnClickListener { toggle() } }
        root.addView(power, lp(top = 12, h = dp(230)))

        titleTv = tv("", 24f, bold = true).apply { gravity = Gravity.CENTER }
        sub = tv("", 13f, C.MUTED).apply { gravity = Gravity.CENTER }
        root.addView(titleTv)
        root.addView(sub, lp(top = 2, bottom = 18))

        // İstatistik kartları
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        qNum = tv("0", 26f, bold = true)
        bNum = tv("0", 26f, C.GREEN, true)
        val c1 = card().apply { addView(tv("Sorgu", 12f, C.MUTED)); addView(qNum) }
        val c2 = card().apply { addView(tv("Engellenen", 12f, C.MUTED)); addView(bNum) }
        stats.addView(c1, lp(w = 0, weight = 1f).apply { rightMargin = dp(6) })
        stats.addView(c2, lp(w = 0, weight = 1f).apply { leftMargin = dp(6) })
        root.addView(stats, lp(bottom = 20))

        // Sağlayıcılar
        root.addView(section("DNS sağlayıcı"), lp(bottom = 8))
        val provCard = card()
        Providers.all.forEachIndexed { i, p ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setOnClickListener { prefs.providerIdx = i; refreshProviders() }
            }
            val dot = View(this)
            row.addView(dot, lp(w = dp(18), h = dp(18)).apply { rightMargin = dp(12) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(tv(p.name, 15f, bold = true))
            col.addView(tv(p.desc, 12f, C.MUTED))
            row.addView(col, lp(w = 0, weight = 1f))
            provRows.add(row); provDots.add(dot)
            provCard.addView(row, lp(top = if (i == 0) 0 else 8))
        }
        root.addView(provCard, lp(bottom = 20))
        refreshProviders()

        // Premium özellikler
        root.addView(section("Premium özellikler"), lp(bottom = 8))
        val featCard = card()
        featCard.addView(switchRow("Tam VPN modu (WARP)", "Tüm trafiği Cloudflare üzerinden tüneller. Roblox, Discord gibi engelli servisler için", prefs.fullVpn, true) { prefs.fullVpn = it })
        featCard.addView(switchRow("Şifreli DNS (DoH)", "Sorguların HTTPS ile şifrelenir", prefs.doh, true) { prefs.doh = it })
        featCard.addView(switchRow("Reklam ve izleyici engeli", "Reklam / takip alan adlarını yok eder", prefs.adblock, true) { prefs.adblock = it })
        featCard.addView(switchRow("Otomatik başlat", "Telefon açılınca kendiliğinden bağlanır", prefs.autostart, true) { prefs.autostart = it })
        root.addView(featCard, lp(bottom = 20))

        // Gelişmiş
        root.addView(section("Gelişmiş"), lp(bottom = 8))
        val advCard = card()
        advCard.addView(tv("Özel DNS adresi", 14f, bold = true))
        val customDns = field("örn. 1.1.1.1", prefs.customDns, 1)
        advCard.addView(customDns, lp(top = 6, bottom = 14))
        advCard.addView(tv("Kendi engel listen", 14f, bold = true))
        advCard.addView(tv("Her satıra bir alan adı", 12f, C.MUTED))
        val blocked = field("ads.ornek.com", prefs.customBlockedRaw, 3)
        advCard.addView(blocked, lp(top = 6, bottom = 14))
        advCard.addView(tv("WireGuard yapılandırması (isteğe bağlı)", 14f, bold = true))
        advCard.addView(tv("Boş bırakırsan otomatik ücretsiz WARP hesabı açılır", 12f, C.MUTED))
        val wgField = field("[Interface] ... [Peer] ...", prefs.wgCustom, 4)
        advCard.addView(wgField, lp(top = 6, bottom = 14))
        advCard.addView(tv("VPN dışı uygulamalar", 14f, bold = true))
        advCard.addView(tv("Seçtiğin uygulamalar bu DNS'i kullanmaz, normal internetle çalışır", 12f, C.MUTED))
        advCard.addView(Button(this).apply {
            text = "Uygulama seç"
            setAllCaps(false)
            textSize = 14f
            setTextColor(Color.WHITE)
            background = shape(C.FIELD, 12, 1, C.STROKE)
            setOnClickListener { pickApps() }
        }, lp(top = 6, bottom = 14, h = dp(46)))
        advCard.addView(Button(this).apply {
            text = "Kaydet"
            setAllCaps(false)
            textSize = 15f
            setTextColor(Color.WHITE)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.ACCENT, C.ACCENT2)).apply {
                cornerRadius = dp(12).toFloat()
            }
            setOnClickListener {
                prefs.customDns = customDns.text.toString()
                prefs.customBlockedRaw = blocked.text.toString()
                prefs.wgCustom = wgField.text.toString()
                Toast.makeText(this@MainActivity, "Kaydedildi", Toast.LENGTH_SHORT).show()
            }
        }, lp(h = dp(48)))
        root.addView(advCard, lp(bottom = 20))

        // Canlı kayıt
        root.addView(section("Canlı sorgular"), lp(bottom = 8))
        val logCard = card()
        logv = TextView(this).apply {
            textSize = 11f; typeface = Typeface.MONOSPACE; setTextColor(C.MUTED)
            text = "Henüz sorgu yok"
        }
        logCard.addView(logv)
        root.addView(logCard)

        for (i in 0 until root.childCount) {
            val v = root.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(28).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 80L).setDuration(520)
                .setInterpolator(DecelerateInterpolator()).start()
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun pickApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val sel = prefs.excluded.toMutableSet()
        val names = apps.map { it.second }.toTypedArray()
        val checked = BooleanArray(apps.size) { apps[it].first in sel }
        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("VPN dışında kalacak uygulamalar")
            .setMultiChoiceItems(names, checked) { _, i, c ->
                if (c) sel.add(apps[i].first) else sel.remove(apps[i].first)
            }
            .setPositiveButton("Kaydet") { _, _ ->
                prefs.excluded = sel
                Toast.makeText(this, "Kaydedildi. Bağlantıyı kesip tekrar bağlan", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private var lastTitle = ""
    private fun setTitle2(t: String, color: Int) {
        if (t == lastTitle) return
        val first = lastTitle.isEmpty()
        lastTitle = t
        if (first) { titleTv.text = t; titleTv.setTextColor(color); return }
        titleTv.animate().setStartDelay(0).alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(120).withEndAction {
            titleTv.text = t
            titleTv.setTextColor(color)
            titleTv.animate().setStartDelay(0).alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).start()
        }.start()
    }

    private fun toggle() {
        if (DnsVpnService.active) {
            startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
            return
        }
        if (Warp.active) { Warp.disconnect(); return }
        if (Warp.connecting) return
        val i = VpnService.prepare(this)
        if (i != null) { startActivityForResult(i, if (prefs.fullVpn) 2 else 1); return }
        startSelected()
    }

    private fun startSelected() {
        if (prefs.fullVpn) Warp.connect(this) else startService(Intent(this, DnsVpnService::class.java))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if ((req == 1 || req == 2) && res == RESULT_OK) startSelected()
    }

    private val tick = object : Runnable {
        override fun run() {
            val a = DnsVpnService.active || Warp.active
            power.setState(a, Warp.connecting)
            if (Warp.connecting && !a) setTitle2("Bağlanıyor...", C.TEXT)
            else setTitle2(if (a) "Bağlandı" else "Bağlı değil", if (a) C.GREEN else C.TEXT)
            sub.text = when {
                Warp.active -> "Cloudflare WARP · tam VPN"
                a -> "${prefs.provider.name} · ${if (prefs.doh && prefs.provider.doh != null) "şifreli (DoH)" else "standart DNS"}"
                Warp.connecting -> "Bağlanıyor..."
                Warp.error.isNotEmpty() -> Warp.error
                else -> "Bağlanmak için düğmeye dokun"
            }
            qNum.text = DnsVpnService.total.get().toString()
            bNum.text = DnsVpnService.blockedCount.get().toString()
            val lines = synchronized(DnsVpnService.log) { DnsVpnService.log.takeLast(25) }
            logv.text = if (lines.isEmpty()) "Henüz sorgu yok" else lines.joinToString("\n")
            h.postDelayed(this, 1000)
        }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
