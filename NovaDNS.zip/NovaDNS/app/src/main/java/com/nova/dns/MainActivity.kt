package com.nova.dns

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private val h = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var btn: Button
    private lateinit var stats: TextView
    private lateinit var logv: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 14f, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t; textSize = size
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(4))
        }

    private fun sw(t: String, init: Boolean, on: (Boolean) -> Unit): Switch =
        Switch(this).apply {
            text = t; isChecked = init
            setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, c -> on(c) }
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }

        root.addView(label("Nova DNS", 28f, true))
        status = label("", 16f)
        root.addView(status)

        btn = Button(this).apply {
            textSize = 18f
            setOnClickListener { toggle() }
        }
        root.addView(btn, LinearLayout.LayoutParams(-1, dp(64)))

        stats = label("", 14f)
        root.addView(stats)

        root.addView(label("DNS sağlayıcı", 16f, true))
        val spin = Spinner(this)
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Providers.all.map { it.name })
        spin.setSelection(prefs.providerIdx)
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { prefs.providerIdx = pos }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spin)

        root.addView(label("Premium özellikler", 16f, true))
        root.addView(sw("Şifreli DNS (DNS-over-HTTPS)", prefs.doh) { prefs.doh = it })
        root.addView(sw("Reklam / izleyici engelleme", prefs.adblock) { prefs.adblock = it })
        root.addView(sw("Telefon açılınca otomatik başlat", prefs.autostart) { prefs.autostart = it })

        root.addView(label("Özel DNS adresi (sağlayıcı: Özel DNS)"))
        val customDns = EditText(this).apply { hint = "örn. 1.1.1.1"; setText(prefs.customDns); setSingleLine() }
        root.addView(customDns)

        root.addView(label("Kendi engel listen (her satıra bir alan adı)"))
        val blocked = EditText(this).apply {
            hint = "ads.ornek.com"; setText(prefs.customBlockedRaw); minLines = 3
        }
        root.addView(blocked)

        root.addView(Button(this).apply {
            text = "Kaydet"
            setOnClickListener {
                prefs.customDns = customDns.text.toString()
                prefs.customBlockedRaw = blocked.text.toString()
                Toast.makeText(this@MainActivity, "Kaydedildi", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(label("Canlı sorgular (✓ geçti, ✗ engellendi)", 16f, true))
        logv = TextView(this).apply { textSize = 12f; typeface = Typeface.MONOSPACE }
        root.addView(logv)

        setContentView(ScrollView(this).also { it.addView(root) })
    }

    private fun toggle() {
        if (DnsVpnService.active) {
            startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
        } else {
            val i = VpnService.prepare(this)
            if (i != null) startActivityForResult(i, 1) else startService(Intent(this, DnsVpnService::class.java))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1 && res == RESULT_OK) startService(Intent(this, DnsVpnService::class.java))
    }

    private val tick = object : Runnable {
        override fun run() {
            val a = DnsVpnService.active
            status.text = if (a) "● Bağlı — DNS korumalı" else "○ Bağlı değil"
            btn.text = if (a) "Bağlantıyı kes" else "Bağlan"
            stats.text = "Sorgu: ${DnsVpnService.total.get()}   Engellenen: ${DnsVpnService.blockedCount.get()}"
            logv.text = synchronized(DnsVpnService.log) { DnsVpnService.log.takeLast(30).joinToString("\n") }
            h.postDelayed(this, 1000)
        }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
