package com.nova.dns

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object C {
    val BG = 0xFF0B1020.toInt()
    val BG2 = 0xFF1B1245.toInt()
    val CARD = 0xFF151B30.toInt()
    val FIELD = 0xFF0E1328.toInt()
    val STROKE = 0xFF283052.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val MUTED = 0xFF8A93B2.toInt()
    val ACCENT = 0xFF6C5CE7.toInt()
    val ACCENT2 = 0xFF8E7CFF.toInt()
    val GREEN = 0xFF2ED573.toInt()
    val TEAL = 0xFF00D2D3.toInt()
    val SEL = 0x336C5CE7
}

class PowerButton(c: Context) : View(c) {
    private var on = false
    private var busy = false
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    fun setState(active: Boolean, connecting: Boolean) {
        if (active != on || connecting != busy) { on = active; busy = connecting; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val breathe = 1f + 0.03f * sin(t * 2f * PI.toFloat())
        val r = minOf(width, height) / 2f * 0.58f * breathe
        p.shader = null
        p.style = Paint.Style.FILL
        if (on) {
            for (k in 0..1) {
                val ph = (t + k * 0.5f) % 1f
                p.color = Color.argb((80 * (1 - ph)).toInt(), 46, 213, 115)
                c.drawCircle(cx, cy, r * (1f + 0.65f * ph), p)
            }
        }
        p.color = if (on) 0x222ED573 else 0x226C5CE7
        c.drawCircle(cx, cy, r * 1.22f, p)
        p.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            if (on) C.GREEN else C.ACCENT, if (on) C.TEAL else C.ACCENT2, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        if (busy) {
            p.strokeWidth = r * 0.09f
            p.color = C.TEAL
            val ring = r * 1.3f
            c.drawArc(RectF(cx - ring, cy - ring, cx + ring, cy + ring), t * 360f, 110f, false, p)
            p.color = C.ACCENT2
            c.drawArc(RectF(cx - ring, cy - ring, cx + ring, cy + ring), t * 360f + 180f, 60f, false, p)
        }
        p.strokeWidth = r * 0.13f
        p.color = Color.WHITE
        val ir = r * 0.42f
        c.drawArc(RectF(cx - ir, cy - ir, cx + ir, cy + ir), -60f, 300f, false, p)
        c.drawLine(cx, cy - ir * 1.2f, cx, cy - ir * 0.05f, p)
    }
}

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var power: PowerButton
    private lateinit var titleTv: TextView
    private lateinit var sub: TextView
    private lateinit var timeNum: TextView
    private lateinit var appsNum: TextView
    private lateinit var appLines: TextView
    private var connectedAt = 0L
    private var lastTitle = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int = 0, strokeColor: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke > 0) setStroke(dp(stroke), strokeColor)
        }

    private fun tv(t: String, size: Float, color: Int = C.TEXT, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun lp(top: Int = 0, bottom: Int = 0, w: Int = -1, h: Int = -2, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(C.CARD, 18, 1, C.STROKE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private val names = mapOf("com.roblox.client" to "Roblox", "com.discord" to "Discord")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C.BG, C.BG2)))
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG2

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(28))
        }

        root.addView(tv("Nova DNS", 28f, bold = true))
        root.addView(tv("Hızlı  •  Güvenli  •  Otomatik", 13f, C.MUTED))

        power = PowerButton(this).apply { setOnClickListener { toggle() } }
        root.addView(power, lp(top = 12, h = dp(250)))

        titleTv = tv("", 26f, bold = true).apply { gravity = Gravity.CENTER }
        sub = tv("", 13f, C.MUTED).apply { gravity = Gravity.CENTER }
        root.addView(titleTv)
        root.addView(sub, lp(top = 2, bottom = 22))

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timeNum = tv("--:--", 26f, bold = true)
        appsNum = tv("0", 26f, C.GREEN, true)
        val c1 = card().apply { addView(tv("Bağlantı süresi", 12f, C.MUTED)); addView(timeNum) }
        val c2 = card().apply { addView(tv("Korunan uygulama", 12f, C.MUTED)); addView(appsNum) }
        stats.addView(c1, lp(w = 0, weight = 1f).apply { rightMargin = dp(6) })
        stats.addView(c2, lp(w = 0, weight = 1f).apply { leftMargin = dp(6) })
        root.addView(stats, lp(bottom = 14))

        val info = card()
        info.addView(tv("Akıllı mod", 15f, bold = true))
        info.addView(tv("Sadece Türkiye'de engelli uygulamalar VPN'den geçer. Diğer tüm uygulamalar normal internetle çalışır. Hiçbir ayar yapman gerekmez.", 12f, C.MUTED).apply { setPadding(0, dp(4), 0, dp(10)) })
        appLines = tv("", 14f)
        info.addView(appLines)
        root.addView(info)

        for (i in 0 until root.childCount) {
            val v = root.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(28).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 80L).setDuration(520)
                .setInterpolator(DecelerateInterpolator()).start()
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun refreshApps() {
        val installed = Targets.vpnApps(this, false).filter { it != packageName }
        appsNum.text = installed.size.toString()
        appLines.text = Targets.banned.joinToString("\n") { pkg ->
            val n = names[pkg] ?: pkg
            if (pkg in installed) "●  $n — VPN'den geçiyor" else "○  $n — kurulu değil"
        }
    }

    private fun setTitle2(t: String, color: Int) {
        if (t == lastTitle) return
        val first = lastTitle.isEmpty()
        lastTitle = t
        if (first) { titleTv.text = t; titleTv.setTextColor(color); return }
        titleTv.animate().setStartDelay(0).alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(120).withEndAction {
            titleTv.text = t
            titleTv.setTextColor(color)
            titleTv.animate().setStartDelay(0).alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).start()
        }.start()
    }

    private fun toggle() {
        if (Warp.active) { Warp.disconnect(); return }
        if (Warp.connecting) return
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, 2) else Warp.connect(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 2 && res == RESULT_OK) Warp.connect(this)
    }

    private val tick = object : Runnable {
        override fun run() {
            val a = Warp.active
            power.setState(a, Warp.connecting)
            if (Warp.connecting) setTitle2("Bağlanıyor...", C.TEXT)
            else setTitle2(if (a) "Bağlandı" else "Bağlı değil", if (a) C.GREEN else C.TEXT)
            sub.text = when {
                Warp.connecting -> "En hızlı sunucu seçiliyor..."
                a -> "Cloudflare WARP ile korunuyorsun" + (if (Warp.note.isNotEmpty()) "\n${Warp.note}" else "\nOtomatik optimizasyon açık")
                Warp.error.isNotEmpty() -> Warp.error
                else -> "Bağlanmak için düğmeye dokun"
            }
            if (a) {
                if (connectedAt == 0L) connectedAt = System.currentTimeMillis()
                val sec = (System.currentTimeMillis() - connectedAt) / 1000
                timeNum.text = if (sec >= 3600) String.format("%d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
                else String.format("%02d:%02d", sec / 60, sec % 60)
            } else {
                connectedAt = 0L
                timeNum.text = "--:--"
            }
            h.postDelayed(this, 1000)
        }
    }

    override fun onResume() { super.onResume(); refreshApps(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
