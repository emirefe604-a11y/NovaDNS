package com.nova.dns

import android.content.Context

data class Provider(val name: String, val desc: String, val ip: String, val doh: String?)

object Providers {
    val all = listOf(
        Provider("Cloudflare", "1.1.1.1 · En hızlı, gizlilik odaklı", "1.1.1.1", "https://1.1.1.1/dns-query"),
        Provider("Cloudflare Güvenlik", "1.1.1.2 · Zararlı siteleri engeller", "1.1.1.2", "https://1.1.1.2/dns-query"),
        Provider("Cloudflare Aile", "1.1.1.3 · Zararlı + yetişkin içerik engeli", "1.1.1.3", "https://1.1.1.3/dns-query"),
        Provider("Google DNS", "8.8.8.8 · Kararlı ve güvenilir", "8.8.8.8", "https://8.8.8.8/dns-query"),
        Provider("Quad9", "9.9.9.9 · Gizlilik + tehdit koruması", "9.9.9.9", "https://9.9.9.9/dns-query"),
        Provider("AdGuard", "94.140.14.14 · Sağlayıcı seviyesinde reklam engeli", "94.140.14.14", "https://94.140.14.14/dns-query"),
        Provider("Özel DNS", "Kendi DNS adresini gir", "", null)
    )
}

class Prefs(c: Context) {
    private val p = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    var providerIdx: Int
        get() = p.getInt("prov", 0).coerceIn(0, Providers.all.size - 1)
        set(v) = p.edit().putInt("prov", v).apply()
    var doh: Boolean
        get() = p.getBoolean("doh", true)
        set(v) = p.edit().putBoolean("doh", v).apply()
    var adblock: Boolean
        get() = p.getBoolean("adblock", true)
        set(v) = p.edit().putBoolean("adblock", v).apply()
    var autostart: Boolean
        get() = p.getBoolean("autostart", false)
        set(v) = p.edit().putBoolean("autostart", v).apply()
    var customDns: String
        get() = p.getString("customDns", "") ?: ""
        set(v) = p.edit().putString("customDns", v).apply()
    var customBlockedRaw: String
        get() = p.getString("customBlocked", "") ?: ""
        set(v) = p.edit().putString("customBlocked", v).apply()

    var excluded: Set<String>
        get() = p.getStringSet("excluded", emptySet()) ?: emptySet()
        set(v) = p.edit().putStringSet("excluded", HashSet(v)).apply()

    var fullVpn: Boolean
        get() = p.getBoolean("fullVpn", true)
        set(v) = p.edit().putBoolean("fullVpn", v).apply()
    var wgCustom: String
        get() = p.getString("wgCustom", "") ?: ""
        set(v) = p.edit().putString("wgCustom", v).apply()
    var warpCfg: String
        get() = p.getString("warpCfg", "") ?: ""
        set(v) = p.edit().putString("warpCfg", v).apply()

    var includeBrowsers: Boolean
        get() = p.getBoolean("browsers", false)
        set(v) = p.edit().putBoolean("browsers", v).apply()

    val provider: Provider get() = Providers.all[providerIdx]
    val customBlocked: Set<String>
        get() = customBlockedRaw.lines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()

    fun upstreamIp(): String {
        val pr = provider
        return if (pr.ip.isEmpty()) customDns.trim().ifEmpty { "1.1.1.1" } else pr.ip
    }
}

object Blocklist {
    val builtin = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com", "app-measurement.com",
        "adnxs.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net", "scorecardresearch.com",
        "hotjar.com", "mixpanel.com", "appsflyer.com", "adjust.com", "branch.io", "moatads.com",
        "adsrvr.org", "rubiconproject.com", "pubmatic.com", "openx.net", "amazon-adsystem.com",
        "unityads.unity3d.com", "applovin.com", "mopub.com", "inmobi.com", "startapp.com",
        "ads.yahoo.com", "advertising.com", "bat.bing.com", "ads.tiktok.com", "analytics.tiktok.com"
    )

    fun isBlocked(name: String, custom: Set<String>): Boolean {
        var d = name
        while (true) {
            if (d in builtin || d in custom) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }
}

/** Türkiye'de erişim engeli olan uygulamalar: sadece bunlar VPN'den geçer, diğerleri normal internetle çalışır. */
object Targets {
    val banned = listOf("com.roblox.client", "com.discord")
    val browsers = listOf(
        "com.android.chrome", "org.mozilla.firefox", "com.sec.android.app.sbrowser",
        "com.microsoft.emmx", "com.opera.browser", "com.brave.browser",
        "com.duckduckgo.mobile.android", "com.vivaldi.browser"
    )

    fun vpnApps(ctx: Context, withBrowsers: Boolean): List<String> {
        val pm = ctx.packageManager
        val all = banned + (if (withBrowsers) browsers else emptyList())
        val found = all.filter { try { pm.getPackageInfo(it, 0); true } catch (e: Exception) { false } }
        // Hiçbiri kurulu değilse yalnızca kendi uygulamamız tünele girer (diğer uygulamalar etkilenmez).
        return if (found.isEmpty()) listOf(ctx.packageName) else found
    }
}
