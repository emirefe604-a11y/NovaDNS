package com.nova.dns

import android.content.Context

data class Provider(val name: String, val ip: String, val doh: String?)

object Providers {
    val all = listOf(
        Provider("Cloudflare (1.1.1.1) — Hızlı", "1.1.1.1", "https://1.1.1.1/dns-query"),
        Provider("Cloudflare Güvenlik (zararlı site engeli)", "1.1.1.2", "https://1.1.1.2/dns-query"),
        Provider("Cloudflare Aile (zararlı + yetişkin engeli)", "1.1.1.3", "https://1.1.1.3/dns-query"),
        Provider("Google DNS", "8.8.8.8", "https://8.8.8.8/dns-query"),
        Provider("Quad9 (gizlilik + güvenlik)", "9.9.9.9", "https://9.9.9.9/dns-query"),
        Provider("AdGuard (reklam engelli)", "94.140.14.14", "https://94.140.14.14/dns-query"),
        Provider("Özel DNS", "", null)
    )
}

class Prefs(c: Context) {
    private val p = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    var providerIdx: Int
        get() = p.getInt("prov", 0).coerceIn(0, Providers.all.size - 1)
        set(v) = p.edit().putInt("prov", v).apply()
    var doh: Boolean
        get() = p.getBoolean("doh", true)
        set(v) = p.edit().putBoolean("doh", v).apply()
    var adblock: Boolean
        get() = p.getBoolean("adblock", true)
        set(v) = p.edit().putBoolean("adblock", v).apply()
    var autostart: Boolean
        get() = p.getBoolean("autostart", false)
        set(v) = p.edit().putBoolean("autostart", v).apply()
    var customDns: String
        get() = p.getString("customDns", "") ?: ""
        set(v) = p.edit().putString("customDns", v).apply()
    var customBlockedRaw: String
        get() = p.getString("customBlocked", "") ?: ""
        set(v) = p.edit().putString("customBlocked", v).apply()

    val provider: Provider get() = Providers.all[providerIdx]
    val customBlocked: Set<String>
        get() = customBlockedRaw.lines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()

    fun upstreamIp(): String {
        val pr = provider
        return if (pr.ip.isEmpty()) customDns.trim().ifEmpty { "1.1.1.1" } else pr.ip
    }
}

object Blocklist {
    val builtin = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com", "app-measurement.com",
        "adnxs.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net", "scorecardresearch.com",
        "hotjar.com", "mixpanel.com", "appsflyer.com", "adjust.com", "branch.io", "moatads.com",
        "adsrvr.org", "rubiconproject.com", "pubmatic.com", "openx.net", "amazon-adsystem.com",
        "unityads.unity3d.com", "applovin.com", "mopub.com", "inmobi.com", "startapp.com",
        "ads.yahoo.com", "advertising.com", "bat.bing.com", "ads.tiktok.com", "analytics.tiktok.com"
    )

    fun isBlocked(name: String, custom: Set<String>): Boolean {
        var d = name
        while (true) {
            if (d in builtin || d in custom) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }
}
