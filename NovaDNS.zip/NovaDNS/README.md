# Nova DNS
Android için DNS-over-HTTPS + reklam engelleyici + Cloudflare WARP (yerel VPN servisi).

## Modlar
- **Hızlı DNS:** Sadece DNS sorguları (DoH) yönlendirilir; resim/oyun verisi doğrudan, tam hızda gelir.
- **Tam VPN (WARP):** Seçili uygulamaların tüm trafiği WARP tünelinden geçer (otomatik sunucu seçimi, takılma/ağ değişimi izleme).

Uygulamalar sekmesinden hangi uygulamaların korunacağını seç. Ayarlar sekmesinden DNS sağlayıcı, reklam engelleyici ve diğer özellikler.

## APK çıkarma
1. Bu klasörü GitHub'a yükle (repo kökünde `settings.gradle.kts` ve `.github` klasörü olmalı).
2. GitHub > Actions > "Build APK" > Run workflow.
3. Bitince "Artifacts" altından veya Releases > latest'ten APK'yı indir.
