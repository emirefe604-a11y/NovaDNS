# Nova DNS
Android için DNS-over-HTTPS + reklam engelleyici (yerel VPN servisi).

## APK çıkarma
1. Bu klasörü GitHub'a yükle (repo kökünde `settings.gradle.kts` ve `.github` klasörü olmalı).
2. GitHub > Actions > "Build APK" > Run workflow.
3. Bitince "Artifacts" altından `NovaDNS-apk` indir (release + debug APK içerir).
