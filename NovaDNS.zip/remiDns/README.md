# remiDns

Cloudflare WARP (WireGuard) tabanlı basit Android VPN uygulaması.
Tek dokunuşla ücretsiz bir WARP hesabı açar ve bağlanır. Mobil veri ve Wi‑Fi'da çalışır.

## APK nasıl alınır
1. GitHub'da yeni bir repo aç, bu klasörün içindekileri yükle.
2. Repo'da **Actions** sekmesine gir → **Build APK** → **Run workflow**.
3. Bitince çalıştırmanın sayfasında **Artifacts → remiDns-apk** dosyasını indir.
4. Zip'ten çıkan `app-debug.apk`'yı telefona kur (bilinmeyen kaynaklara izin ver).

## Notlar
- WARP kaydı Cloudflare'ın resmi olmayan API'sini kullanır. Çalışmazsa `WarpRegistrar.kt` içindeki sürüm numarasını güncelle
  veya `wgcf` ile ürettiğin yapılandırmayı uygulamadaki kutuya yapıştır.
- Uygulama yalnızca debug imzalıdır; kişisel kullanım içindir.

## Özellikler
- **Otomatik port seçimi:** 2408, 500, 1701, 4500 sırayla denenir; yanıt veren ilk port kullanılır.
- **Hız modu:** Sadece Roblox ve Discord VPN'den geçer, diğer uygulamalar normal gider.
- **WARP+ anahtarı:** Kendi lisans anahtarını girebilirsin (1.1.1.1 uygulamasından satın alınır).
- **DNS seçimi:** Cloudflare, Google, AdGuard, Quad9 veya kendi adresin.
- **Bağlantı ayarları:** Port, MTU ve IPv6 uygulamadan değiştirilir.
- **Logo:** `res/drawable/ic_logo.xml` ve adaptive icon dosyaları.
- **Otomatik mod (varsayılan):** İlk bağlantıda port, MTU, IPv6 ve DNS hız ölçülerek seçilir (yaklaşık 1 dakika). Sonuç kaydedilir, sonraki bağlantılar anında olur. "Yeniden optimize et" ile tekrar ölçülür. Tüm ayarları elle değiştirmek için "Elle ayarla"yı aç.
- **Sunucum modu:** Ayarlar → Kendi sunucum bölümüne `.conf` içeriğini bir kez kaydet ("Panodan al ve kaydet"). Ana ekranda "Sunucum"u seçince tek dokunuşla bağlanır.
- **WARP tarzı arayüz:** Tek açma/kapama anahtarı; ayarlar "⚙ Ayarlar" altında gizli.
