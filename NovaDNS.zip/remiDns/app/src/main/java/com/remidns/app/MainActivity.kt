package com.remidns.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

class MainActivity : Activity() {

    companion object {
        private var backend: GoBackend? = null
        private val tunnel = object : Tunnel {
            override fun getName(): String = "remidns"
            override fun onStateChange(newState: Tunnel.State) {}
        }
        private const val REQ_VPN = 1
        private val PORTS = listOf(2408, 500, 1701, 4500)
        private const val GAME_APPS = "com.roblox.client, com.discord"
        private val DNS = mapOf(
            "cloudflare" to "1.1.1.1, 1.0.0.1",
            "google" to "8.8.8.8, 8.8.4.4",
            "adguard" to "94.140.14.14, 94.140.15.15",
            "quad9" to "9.9.9.9, 149.112.112.112"
        )
    }

    private lateinit var status: TextView
    private lateinit var sub: TextView
    private lateinit var button: View
    private lateinit var thumb: View
    private lateinit var srvInfo: TextView
    private lateinit var settingsBox: LinearLayout
    private lateinit var manual: EditText
    private lateinit var licenseBox: EditText
    private lateinit var customDns: EditText
    private lateinit var profileInfo: TextView
    private lateinit var manualBox: LinearLayout
    private var connected = false
    private var busy = false

    private data class Profile(val port: Int, val mtu: Int, val nov6: Boolean, val dns: String)

    private val ink = Color.parseColor("#14173A")
    private val card = Color.parseColor("#1D2048")
    private val chip = Color.parseColor("#2A2E63")
    private val accent = Color.parseColor("#7B7BFF")
    private val green = Color.parseColor("#3DDC97")
    private val muted = Color.parseColor("#9EA4CF")
    private val prefs by lazy { getSharedPreferences("remidns", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ink
        window.navigationBarColor = ink
        if (backend == null) backend = GoBackend(applicationContext)
        buildUi()
        refresh()
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radiusDp: Int, oval: Boolean = false) = GradientDrawable().apply {
        setColor(color)
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radiusDp).toFloat()
    }

    private fun cardView(parent: LinearLayout, title: String, desc: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(card, 20)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        c.addView(TextView(this).apply {
            text = title; textSize = 16f; setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        })
        if (desc != null) c.addView(TextView(this).apply {
            text = desc; textSize = 12f; setTextColor(muted); setPadding(0, dp(2), 0, dp(10))
        })
        parent.addView(c, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) })
        return c
    }

    private fun chips(key: String, options: List<Pair<String, String>>, def: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<TextView>()
        fun paint() {
            val cur = prefs.getString(key, def)
            views.forEachIndexed { i, v ->
                val on = options[i].second == cur
                v.background = shape(if (on) accent else chip, 18)
                v.setTextColor(if (on) ink else Color.WHITE)
            }
        }
        options.forEach { (label, value) ->
            val v = TextView(this).apply {
                text = label; textSize = 13f
                setPadding(dp(14), dp(9), dp(14), dp(9))
                setOnClickListener {
                    prefs.edit().putString(key, value).apply(); paint()
                    if (key == "dns") customDns.visibility = if (value == "custom") View.VISIBLE else View.GONE
                }
            }
            views.add(v)
            row.addView(v, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(8) })
        }
        paint()
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun label(parent: LinearLayout, t: String) = parent.addView(TextView(this).apply {
        text = t; textSize = 12f; setTextColor(muted); setPadding(0, dp(12), 0, dp(6))
    })

    private fun toggle(parent: LinearLayout, text: String, key: String, def: Boolean) =
        parent.addView(Switch(this).apply {
            this.text = text; setTextColor(Color.WHITE); textSize = 14f
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() }
            setPadding(0, dp(6), 0, dp(6))
        })

    private fun input(hint: String, lines: Int, text: String = "") = EditText(this).apply {
        this.hint = hint; setText(text)
        setHintTextColor(Color.parseColor("#5A5F80"))
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.TOP; minLines = lines
        background = shape(chip, 12)
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun smallButton(parent: LinearLayout, text: String, onClick: () -> Unit) =
        parent.addView(Button(this).apply {
            this.text = text; textSize = 13f; isAllCaps = false
            setTextColor(Color.WHITE); background = shape(chip, 12)
            setOnClickListener { onClick() }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(44)
        ).apply { topMargin = dp(10) })

    private fun msg(t: String) {
        sub.text = t
        android.widget.Toast.makeText(this, t, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(40), dp(18), dp(40))
        }

        // Logo + ad
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            clipToOutline = true
            background = shape(ink, 20)
        }, LinearLayout.LayoutParams(dp(64), dp(64)))
        root.addView(TextView(this).apply {
            text = "remiDns"; textSize = 26f; setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            setPadding(0, dp(8), 0, 0)
        })

        // WARP tarzı açma/kapama anahtarı
        val track = FrameLayout(this).apply {
            background = shape(chip, 46)
            setOnClickListener { toggle() }
        }
        thumb = View(this).apply { background = shape(Color.WHITE, 0, oval = true) }
        track.addView(thumb, FrameLayout.LayoutParams(dp(76), dp(76)).apply {
            gravity = Gravity.CENTER_VERTICAL; leftMargin = dp(8)
        })
        button = track
        root.addView(track, LinearLayout.LayoutParams(dp(176), dp(92)).apply { topMargin = dp(44) })

        status = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); setPadding(0, dp(22), 0, 0)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        root.addView(status)
        sub = TextView(this).apply {
            textSize = 13f; setTextColor(muted); gravity = Gravity.CENTER
            setPadding(dp(8), dp(4), dp(8), 0)
        }
        root.addView(sub)

        // WARP / Sunucum seçimi
        root.addView(chips("mode", listOf("WARP" to "warp", "Sunucum" to "server"), "warp"),
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(26) })

        // Ayarlar (kapalı başlar)
        settingsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
        }
        root.addView(TextView(this).apply {
            text = "⚙  Ayarlar"; textSize = 15f; setTextColor(accent)
            setPadding(dp(16), dp(28), dp(16), dp(8))
            setOnClickListener {
                settingsBox.visibility = if (settingsBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        })
        root.addView(settingsBox, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // Kendi sunucum
        val srv = cardView(settingsBox, "Kendi sunucum",
            "Sunucundan aldığın .conf içeriğini bir kez kaydet. Sonra ana ekranda Sunucum'u seçip tek dokunuşla bağlan.")
        srvInfo = TextView(this).apply { textSize = 12f; setTextColor(accent) }
        srv.addView(srvInfo)
        manual = input("[Interface] ...", 4)
        srv.addView(manual, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })
        smallButton(srv, "Panodan al ve kaydet") { importClipboard() }
        smallButton(srv, "Yazılanı kaydet") { saveServer(manual.text.toString()) }
        smallButton(srv, "Kayıtlı sunucuyu sil") {
            prefs.edit().remove("server_cfg").apply(); showServer(); msg("Sunucu silindi")
        }

        // Otomatik ayarlar (WARP)
        val auto = cardView(settingsBox, "Otomatik ayarlar (WARP)",
            "Port, MTU, IPv6 ve DNS en hızlı olacak şekilde kendiliğinden seçilir. İlk bağlantı yaklaşık 1 dakika sürer, sonrakiler anında bağlanır.")
        profileInfo = TextView(this).apply { textSize = 12f; setTextColor(accent) }
        auto.addView(profileInfo)
        smallButton(auto, "Yeniden optimize et") { reoptimize() }
        auto.addView(Switch(this).apply {
            text = "Elle ayarla"; setTextColor(Color.WHITE); textSize = 14f
            isChecked = prefs.getBoolean("manual", false)
            setPadding(0, dp(10), 0, dp(4))
            setOnCheckedChangeListener { _, v ->
                prefs.edit().putBoolean("manual", v).apply()
                manualBox.visibility = if (v) View.VISIBLE else View.GONE
            }
        })
        manualBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        settingsBox.addView(manualBox)
        manualBox.visibility = if (prefs.getBoolean("manual", false)) View.VISIBLE else View.GONE

        val speed = cardView(manualBox, "Hız modu",
            "Sadece Roblox ve Discord VPN'den geçer, diğer uygulamalar normal gider. Değişince yeniden bağlan.")
        toggle(speed, "Sadece Roblox + Discord", "split", false)

        val dns = cardView(manualBox, "DNS sunucusu", "VPN içinde kullanılacak DNS.")
        customDns = input("1.1.1.1, 1.0.0.1", 1, prefs.getString("customdns", "") ?: "")
        dns.addView(chips("dns", listOf(
            "Cloudflare" to "cloudflare", "Google" to "google",
            "AdGuard" to "adguard", "Quad9" to "quad9", "Özel" to "custom"
        ), "cloudflare"))
        dns.addView(customDns)
        customDns.visibility = if (prefs.getString("dns", "cloudflare") == "custom") View.VISIBLE else View.GONE

        val net = cardView(manualBox, "Bağlantı ayarları",
            "Resimler geç geliyor veya yüklenmiyorsa MTU'yu 1280'e al, IPv6'yı kapat ve farklı port dene.")
        label(net, "Port")
        net.addView(chips("port", listOf(
            "Otomatik" to "auto", "2408" to "2408", "500" to "500", "1701" to "1701", "4500" to "4500"
        ), "auto"))
        label(net, "MTU")
        net.addView(chips("mtu", listOf("1280" to "1280", "1380" to "1380", "1420" to "1420"), "1280"))
        toggle(net, "IPv6'yı kapat", "nov6", false)

        // WARP+
        val plus = cardView(settingsBox, "WARP+ anahtarı",
            "1.1.1.1 uygulamasından satın aldığın veya sana verilen lisansı gir.")
        licenseBox = input("xxxxxxxx-xxxxxxxx-xxxxxxxx", 1)
        plus.addView(licenseBox)
        smallButton(plus, "Anahtarı uygula") { applyLicense() }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(ink); isFillViewport = true; addView(root)
        })
        showProfile()
        showServer()
        render(false)
    }

    private fun showServer() {
        val t = prefs.getString("server_cfg", null)
        srvInfo.text = if (t == null) "Kayıtlı sunucu yok" else {
            val ep = Regex("Endpoint\\s*=\\s*(\\S+)").find(t)?.groupValues?.get(1) ?: "?"
            "Kayıtlı sunucu: $ep ✓"
        }
    }

    private fun saveServer(raw: String) {
        val t = raw.trim()
        if (t.isEmpty()) { msg("Yapılandırma boş"); return }
        try { Config.parse(ByteArrayInputStream(t.toByteArray())) }
        catch (e: Exception) { msg("Geçersiz yapılandırma: ${e.message}"); return }
        prefs.edit().putString("server_cfg", t).apply()
        manual.setText("")
        showServer()
        msg("Kaydedildi. Ana ekranda Sunucum'u seç")
    }

    private fun importClipboard() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = cm.primaryClip
        val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        if (t.isBlank()) { msg("Panoda metin yok. Önce .conf içeriğini kopyala"); return }
        saveServer(t)
    }

    private fun render(up: Boolean) {
        connected = up; busy = false; button.isEnabled = true
        button.background = shape(if (up) accent else chip, 46)
        thumb.animate().translationX(if (up) dp(84).toFloat() else 0f).setDuration(180).start()
        status.text = if (up) "Bağlı" else "Bağlı değil"
        val server = prefs.getString("mode", "warp") == "server"
        sub.text = when {
            up && server -> "Sunucunun üzerinden korunuyorsun"
            up -> "WARP üzerinden korunuyorsun"
            else -> "Bağlanmak için dokun"
        }
    }

    private fun refresh() {
        Thread {
            val up = try { backend!!.getState(tunnel) == Tunnel.State.UP } catch (e: Exception) { false }
            runOnUiThread { render(up) }
        }.start()
    }

    private fun toggle() {
        if (busy) return
        if (connected) { disconnect(); return }
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, REQ_VPN) else connect()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) connect() else sub.text = "VPN izni verilmedi"
        }
    }

    private fun ensureAccount(): String {
        prefs.getString("cfg", null)?.let { return it }
        val r = WarpRegistrar.register()
        prefs.edit().putString("cfg", r.config).putString("id", r.id).putString("token", r.token).apply()
        return r.config
    }

    private fun currentDns(): String {
        val k = prefs.getString("dns", "cloudflare")!!
        if (k == "custom") {
            val v = customDns.text.toString().trim()
            prefs.edit().putString("customdns", v).apply()
            if (!Regex("^[0-9a-fA-F:.]+(\\s*,\\s*[0-9a-fA-F:.]+)*$").matches(v))
                throw IOException("Geçersiz DNS adresi")
            return v
        }
        return DNS[k] ?: DNS.getValue("cloudflare")
    }

    private fun tune(base: String, port: Int, dns: String, onlyGames: Boolean): String {
        var t = base
        t = t.replace(Regex("Endpoint = ([^:\\s]+):\\d+"), "Endpoint = \$1:$port")
        t = t.replace(Regex("DNS = .*"), "DNS = $dns")
        t = t.replace(Regex("MTU = \\d+"), "MTU = ${prefs.getString("mtu", "1280")}")
        if (prefs.getBoolean("nov6", false)) {
            t = t.replace(Regex(",\\s*[0-9a-fA-F:]+/128"), "").replace(", ::/0", "")
        }
        if (onlyGames) t = t.replace(Regex("(MTU = \\d+)"), "\$1\nIncludedApplications = $GAME_APPS")
        return t
    }

    private fun applyLicense() {
        val key = licenseBox.text.toString().trim()
        if (key.isEmpty()) { sub.text = "Önce anahtarı gir"; return }
        sub.text = "Anahtar uygulanıyor…"
        Thread {
            try {
                ensureAccount()
                WarpRegistrar.applyLicense(prefs.getString("id", "")!!, prefs.getString("token", "")!!, key)
                runOnUiThread { sub.text = "WARP+ anahtarı uygulandı, yeniden bağlan" }
            } catch (e: Exception) {
                runOnUiThread { sub.text = "Hata: ${e.message}" }
            }
        }.start()
    }

    private fun connect() {
        when {
            prefs.getString("mode", "warp") == "server" -> connectServer()
            prefs.getBoolean("manual", false) -> connectManual()
            else -> connectAuto()
        }
    }

    private fun reachable(): Boolean = try {
        val c = URL("https://www.cloudflare.com/cdn-cgi/trace").openConnection() as HttpURLConnection
        c.connectTimeout = 5000; c.readTimeout = 5000
        c.responseCode in 200..299
    } catch (_: Exception) { false }

    private fun connectServer() {
        val text = prefs.getString("server_cfg", null)
        if (text == null) { msg("Önce Ayarlar'dan sunucu yapılandırmanı kaydet"); return }
        busy = true
        button.isEnabled = false
        status.text = "Bağlanıyor…"
        sub.text = "Sunucuna bağlanılıyor…"
        Thread {
            try {
                try { backend!!.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
                val cfg = Config.parse(ByteArrayInputStream(text.toByteArray()))
                backend!!.setState(tunnel, Tunnel.State.UP, cfg)
                var ok = false
                repeat(2) { if (!ok && reachable()) ok = true }
                if (!ok) {
                    backend!!.setState(tunnel, Tunnel.State.DOWN, null)
                    throw IOException("Sunucuya ulaşılamadı. Oracle'da ve sunucuda UDP portunun açık olduğunu kontrol et")
                }
                runOnUiThread { render(true) }
            } catch (e: Exception) {
                try { backend!!.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
                runOnUiThread {
                    render(false)
                    status.text = "Bağlanamadı"
                    sub.text = e.message ?: e.javaClass.simpleName
                }
            }
        }.start()
    }

    // ---------- OTOMATİK MOD ----------

    private fun dnsName(v: String) = DNS.entries.firstOrNull { it.value == v }?.key
        ?.replaceFirstChar { it.uppercase() } ?: "Özel"

    private fun showProfile() {
        val p = loadProfile()
        profileInfo.text = if (p == null) "Henüz optimize edilmedi"
        else "Seçilen: port ${p.port} · MTU ${p.mtu} · IPv6 ${if (p.nov6) "kapalı" else "açık"} · DNS ${dnsName(p.dns)}"
    }

    private fun loadProfile(): Profile? = try {
        prefs.getString("profile", null)?.split("|")?.let {
            Profile(it[0].toInt(), it[1].toInt(), it[2].toBoolean(), it[3])
        }
    } catch (e: Exception) { null }

    private fun saveProfile(p: Profile) {
        prefs.edit().putString("profile", "${p.port}|${p.mtu}|${p.nov6}|${p.dns}").apply()
    }

    private fun tuneProfile(base: String, p: Profile): String {
        var t = base
        t = t.replace(Regex("Endpoint = ([^:\\s]+):\\d+"), "Endpoint = \$1:${p.port}")
        t = t.replace(Regex("DNS = .*"), "DNS = ${p.dns}")
        t = t.replace(Regex("MTU = \\d+"), "MTU = ${p.mtu}")
        if (p.nov6) t = t.replace(Regex(",\\s*[0-9a-fA-F:]+/128"), "").replace(", ::/0", "")
        return t
    }

    /** Profili uygular ve el sıkışmanın tamamlanmasını bekler. */
    private fun bringUp(base: String, p: Profile): Boolean {
        try { backend!!.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
        Thread.sleep(300)
        val cfg = Config.parse(ByteArrayInputStream(tuneProfile(base, p).toByteArray()))
        backend!!.setState(tunnel, Tunnel.State.UP, cfg)
        val end = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < end) {
            if (backend!!.getStatistics(tunnel).totalRx() > 0) return true
            Thread.sleep(250)
        }
        return false
    }

    /** Tünel üzerinden indirme hızı (bayt/sn). */
    private fun speedTest(): Long {
        val t0 = System.nanoTime()
        var total = 0L
        try {
            val c = URL("https://speed.cloudflare.com/__down?bytes=1500000").openConnection() as HttpURLConnection
            c.connectTimeout = 4000; c.readTimeout = 4000
            val buf = ByteArray(16384)
            c.inputStream.use {
                while (System.nanoTime() - t0 < 4_000_000_000L) {
                    val n = it.read(buf)
                    if (n < 0) break
                    total += n
                }
            }
        } catch (_: Exception) {}
        val sec = (System.nanoTime() - t0) / 1e9
        return if (total > 0) (total / sec).toLong() else 0L
    }

    /** Roblox CDN'ine DNS çözümü + TCP bağlantı süresi (ms); düşük olan iyi. */
    private fun cdnLatencyMs(): Long {
        val times = mutableListOf<Long>()
        for (host in listOf("t0.rbxcdn.com", "www.roblox.com")) {
            try {
                val t = System.nanoTime()
                val addr = InetAddress.getByName(host)
                Socket().use { it.connect(InetSocketAddress(addr, 443), 3000) }
                times.add((System.nanoTime() - t) / 1_000_000)
            } catch (_: Exception) {}
        }
        return if (times.isEmpty()) Long.MAX_VALUE / 2 else times.average().toLong()
    }

    private fun optimize(base: String): Profile {
        var best = Profile(2408, 1280, false, DNS.getValue("cloudflare"))
        var step = 0
        val total = 10
        fun progress() = runOnUiThread { sub.text = "Optimize ediliyor ($step/$total)…" }
        fun score(p: Profile): Long {
            step++; progress()
            return try { if (bringUp(base, p)) speedTest() else 0L } catch (_: Exception) { 0L }
        }

        var bestScore = -1L
        for (port in PORTS) {
            val p = best.copy(port = port)
            val s = score(p)
            if (s > bestScore) { bestScore = s; best = p }
            if (s > 3_000_000) break
        }
        if (bestScore <= 0) throw IOException("Hiçbir port yanıt vermedi")

        for (m in listOf(1380, 1420)) {
            val p = best.copy(mtu = m)
            val s = score(p)
            if (s > bestScore * 1.1) { bestScore = s; best = p }
        }
        run {
            val p = best.copy(nov6 = !best.nov6)
            val s = score(p)
            if (s > bestScore * 1.1) { bestScore = s; best = p }
        }

        var bestLat = Long.MAX_VALUE
        var bestDns = best.dns
        for (k in listOf("cloudflare", "google", "quad9")) {
            step++; progress()
            val p = best.copy(dns = DNS.getValue(k))
            val ok = try { bringUp(base, p) } catch (_: Exception) { false }
            if (!ok) continue
            val lat = cdnLatencyMs()
            if (lat < bestLat) { bestLat = lat; bestDns = p.dns }
        }
        return best.copy(dns = bestDns)
    }

    private fun connectAuto() {
        busy = true
        button.isEnabled = false
        status.text = "Bağlanıyor…"
        sub.text = "Hazırlanıyor…"
        Thread {
            try {
                val base = ensureAccount()
                var prof = loadProfile()
                if (prof != null && !bringUp(base, prof)) prof = null
                if (prof == null) {
                    prof = optimize(base)
                    saveProfile(prof)
                    if (!bringUp(base, prof)) throw IOException("Bağlantı kurulamadı")
                }
                runOnUiThread { render(true); showProfile() }
            } catch (e: Exception) {
                try { backend!!.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
                runOnUiThread {
                    render(false)
                    status.text = "Bağlanamadı"
                    sub.text = e.message ?: e.javaClass.simpleName
                }
            }
        }.start()
    }

    private fun reoptimize() {
        if (busy) return
        prefs.edit().remove("profile").apply()
        showProfile()
        if (connected) {
            busy = true
            Thread {
                try { backend!!.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
                runOnUiThread { render(false); connect() }
            }.start()
        } else toggle()
    }

    // ---------- ELLE MOD ----------

    private fun connectManual() {
        val dns = try { currentDns() } catch (e: Exception) { sub.text = "Hata: ${e.message}"; return }
        busy = true
        button.isEnabled = false
        status.text = "Bağlanıyor…"
        val pasted = ""
        val onlyGames = prefs.getBoolean("split", false)
        val sel = prefs.getString("port", "auto") ?: "auto"
        Thread {
            try {
                val base = if (pasted.isNotEmpty()) pasted else ensureAccount()
                val ports: List<Int?> = when {
                    pasted.isNotEmpty() -> listOf(null)
                    sel == "auto" -> PORTS
                    else -> listOf(sel.toInt())
                }
                var ok = false
                for (p in ports) {
                    val text = if (p == null) base else tune(base, p, dns, onlyGames)
                    if (p != null) runOnUiThread { sub.text = "Port $p deneniyor…" }
                    val cfg = Config.parse(ByteArrayInputStream(text.toByteArray()))
                    backend!!.setState(tunnel, Tunnel.State.UP, cfg)
                    if (p == null || ports.size == 1) { ok = true; break }
                    Thread.sleep(3500)
                    if (backend!!.getStatistics(tunnel).totalRx() > 0) { ok = true; break }
                    backend!!.setState(tunnel, Tunnel.State.DOWN, null)
                }
                if (!ok) throw IOException("Hiçbir port yanıt vermedi")
                runOnUiThread { render(true) }
            } catch (e: Exception) {
                runOnUiThread {
                    render(false)
                    status.text = "Bağlanamadı"
                    sub.text = e.message ?: e.javaClass.simpleName
                }
            }
        }.start()
    }

    private fun disconnect() {
        busy = true
        button.isEnabled = false
        Thread {
            try { backend!!.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
            runOnUiThread { render(false) }
        }.start()
    }
}
